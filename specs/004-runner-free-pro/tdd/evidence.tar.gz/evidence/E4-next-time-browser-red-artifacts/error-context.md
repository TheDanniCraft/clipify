# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: .features-gen/bdd/runner-standby.feature.spec.js >> Runner standby customization >> A Pro owner previews the next broadcast in its saved timezone
- Location: .features-gen/bdd/runner-standby.feature.spec.js:30:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByRole('switch', { name: 'Show next broadcast time', exact: true })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByRole('switch', { name: 'Show next broadcast time', exact: true }) with timeout 15000ms
  - waiting for getByRole('switch', { name: 'Show next broadcast time', exact: true })

```

```yaml
- button "Enable support chat"
- button "Report a problem":
  - img
  - text: Report a problem
- alert
- navigation:
  - link "Clipify":
    - /url: /dashboard
    - img
    - paragraph: Clipify
  - list:
    - listitem:
      - text: Account
      - group:
        - text: E2E Creator Account
        - button "E2E Creator Account Account context Account"
    - listitem:
      - button "Toggle Theme":
        - img
    - listitem:
      - button "Open profile menu":
        - text: E2
        - status "Online"
- main:
  - heading "Runner Settings" [level=1]
  - paragraph: Configure hardware streaming
  - button:
    - img
  - heading "Runner Settings" [level=1]
  - text: Streaming (LIVE)
  - button "Unlink runner" [disabled]:
    - img
  - separator
  - heading "Setup Your Runner" [level=2]
  - paragraph: This runner is linked to your account but is not connected yet. Download the runner for your operating system, run it, and approve the browser enrollment prompt. It will connect to this Clipify environment automatically.
  - button "Download for Windows":
    - img
    - text: Download for Windows
  - button "Download for Linux":
    - img
    - text: Download for Linux
  - button "Download for macOS":
    - img
    - text: Download for macOS
  - heading "Appearance" [level=2]
  - paragraph: Choose where Clipify attribution appears on generated content.
  - text: Standby logo
  - button "Standby logo"
  - text: PNG, JPEG or WebP, up to 2 MiB. Standby background image
  - button "Standby background image"
  - text: PNG, JPEG or WebP, up to 2 MiB. Standby background color
  - textbox "Standby background color": "#000000"
  - text: Standby message
  - textbox "Standby message"
  - text: 0/160 characters
  - switch "Show Clipify attribution"
  - text: Show Clipify attribution Attribution corner
  - button "Bottom right Attribution corner": Bottom right
  - button "Save appearance"
  - iframe
  - heading "Broadcast schedule" [level=2]:
    - img
    - text: Broadcast schedule
  - paragraph: Plan one-time or weekly broadcasts. Your Runner computer must stay on.
  - button "Pause automation"
  - button "Add schedule":
    - img
    - text: Add schedule
  - region "Broadcast calendar":
    - heading "Broadcast calendar" [level=3]
    - paragraph: Week view · Dates use UTC
    - text: Displayed date
    - textbox "Displayed date": 2026-10-18
    - text: Calendar timezone
    - combobox "Calendar timezone":
      - option "UTC" [selected]
      - option "Europe/Berlin"
    - button "Previous week": Previous
    - button "Today"
    - button "Next week": Next
    - text: Sun 18 Mon 19 Tue 20 Wed 21 Thu 22 Fri 23 Sat 24 1 AM 2 AM 3 AM 4 AM 5 AM 6 AM 7 AM 8 AM 9 AM 10 AM 11 AM 12 PM 1 PM 2 PM 3 PM 4 PM 5 PM 6 PM 7 PM 8 PM 9 PM 10 PM 11 PM
    - button "Active window Open event details" [disabled]
    - button "Active window Open event details" [disabled]
  - list "Saved schedules":
    - listitem:
      - paragraph: Active window
      - paragraph: 2026-10-17 00:00 — 2026-10-19 23:59
      - paragraph: 71.98333333333333 hours · UTC
      - paragraph: This occurrence is active. Its schedule stays locked until the window ends.
      - button "Resume Active window" [disabled]: Resume
      - button "Edit Active window" [disabled]:
        - img
        - text: Edit
    - listitem:
      - paragraph: Future Berlin broadcast
      - paragraph: 2027-01-15 14:00 — 2027-01-15 16:00
      - paragraph: 2 hours · Europe/Berlin
      - button "Edit Future Berlin broadcast":
        - img
        - text: Edit
  - heading "Destinations" [level=2]
  - paragraph: Save your streaming destinations and manage their protected keys.
  - button "Add destination":
    - img
    - text: Add destination
  - list:
    - listitem:
      - paragraph: Scheduled loopback
      - paragraph: Custom RTMP · 127.0.0.1:1949
      - text: Key saved
      - button "Edit Scheduled loopback":
        - img
        - text: Edit
      - button "Delete Scheduled loopback":
        - img
```

# Test source

```ts
  334 | 
  335 | Then("their uploaded logo matches preview and saved generated standby", async ({ page, mcpWorld }) => {
  336 | 	const sharp = (await import("sharp")).default;
  337 | 	const bytes = await sharp({ create: { width: 16, height: 16, channels: 4, background: { r: 180, g: 40, b: 120, alpha: 0.8 } } })
  338 | 		.png()
  339 | 		.toBuffer();
  340 | 	const upload = page.getByLabel("Standby logo", { exact: true });
  341 | 	await expect(upload).toBeVisible();
  342 | 	await upload.setInputFiles({ name: "logo.png", mimeType: "image/png", buffer: bytes });
  343 | 	const preview = page.frameLocator('iframe[title="Runner appearance preview"]').getByRole("img", { name: "Standby logo", exact: true });
  344 | 	await expect(preview).toBeVisible();
  345 | 	await expect(preview).toHaveJSProperty("naturalWidth", 16);
  346 | 	await expect(preview).toHaveJSProperty("naturalHeight", 16);
  347 | 	await page.getByRole("button", { name: "Save appearance", exact: true }).click();
  348 | 	await expect(page.getByRole("status").filter({ hasText: "Appearance saved" })).toBeVisible();
  349 | 	await page.reload();
  350 | 	await expect(preview).toBeVisible();
  351 | 	await expect(preview).toHaveJSProperty("naturalWidth", 16);
  352 | 	const world = presentationState(mcpWorld.input);
  353 | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  354 | 	expect(response.status()).toBe(200);
  355 | 	const { url } = await response.json();
  356 | 	await page.goto(`http://127.0.0.1:3107${url}`);
  357 | 	const logo = page.getByRole("img", { name: "Standby logo", exact: true });
  358 | 	await expect(logo).toBeVisible();
  359 | 	await expect(logo).toHaveJSProperty("naturalWidth", 16);
  360 | 	await expect(logo).toHaveJSProperty("naturalHeight", 16);
  361 | 	const policy = await page.request.get(`http://127.0.0.1:3107/runner/presentation/${world.sessionId}/policy`);
  362 | 	expect(policy.status()).toBe(200);
  363 | 	expect(policy.headers()["cache-control"]).toBe("private, no-store");
  364 | 	const renewed = policy.headers()["set-cookie"] ?? "";
  365 | 	expect(renewed.includes("clipify_runner_presentation=")).toBe(true);
  366 | 	expect(renewed.includes(`Path=/runner/presentation/${world.sessionId}`)).toBe(true);
  367 | 	expect(/HttpOnly/i.test(renewed)).toBe(true);
  368 | 	expect(/Max-Age=600/i.test(renewed)).toBe(true);
  369 | 	expect(/SameSite=strict/i.test(renewed)).toBe(true);
  370 | });
  371 | 
  372 | Then("their standby message matches draft preview and the already active presentation", async ({ page, mcpWorld }) => {
  373 | 	const world = presentationState(mcpWorld.input);
  374 | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  375 | 	expect(response.status()).toBe(200);
  376 | 	const { url } = await response.json();
  377 | 	const output = await page.context().newPage();
  378 | 	try {
  379 | 		await output.clock.install({ time: Date.now() });
  380 | 		await output.goto(`http://127.0.0.1:3107${url}`);
  381 | 		await expect(output.locator("[data-runner-standby]")).toBeVisible();
  382 | 		const marker = await output.locator("[data-runner-content-phase]").elementHandle();
  383 | 		expect(marker).not.toBeNull();
  384 | 		const message = "Back soon <3 — thanks for watching!";
  385 | 		const editor = page.getByLabel("Standby message", { exact: true });
  386 | 		await expect(editor).toBeVisible();
  387 | 		await editor.fill(message);
  388 | 		const preview = page.frameLocator('iframe[title="Runner appearance preview"]').getByText(message, { exact: true });
  389 | 		await expect(preview).toBeVisible();
  390 | 		await page.getByRole("button", { name: "Save appearance", exact: true }).click();
  391 | 		await expect(page.getByRole("status").filter({ hasText: "Appearance saved" })).toBeVisible();
  392 | 		await page.reload();
  393 | 		await expect(editor).toHaveValue(message);
  394 | 		await expect(preview).toBeVisible();
  395 | 		await output.clock.fastForward(30001);
  396 | 		await expect(output.getByText(message, { exact: true })).toBeVisible();
  397 | 		await expect(output.locator("[data-runner-presentation-generation]")).toHaveAttribute("data-runner-presentation-generation", world.generation);
  398 | 		expect(await marker!.evaluate((element) => element.isConnected)).toBe(true);
  399 | 	} finally {
  400 | 		await output.close();
  401 | 	}
  402 | });
  403 | 
  404 | Given("its schedule includes a future Berlin broadcast beyond the current cache horizon", async ({ mcpWorld }) => {
  405 | 	const world = presentationState(mcpWorld.input);
  406 | 	const year = new Date().getUTCFullYear() + 1;
  407 | 	const date = `${year}-01-15`;
  408 | 	const expected = `${date}T13:00:00.000Z`;
  409 | 	mcpWorld.input = { ...mcpWorld.input, runnerStandbyNext: { expected, timezone: "Europe/Berlin" } };
  410 | 	const pool = new Pool({ connectionString: browserDatabaseUrl(), max: 2 });
  411 | 	try {
  412 | 		const { encryptString } = await import("@/app/lib/encryption");
  413 | 		const target = randomUUID();
  414 | 		await pool.query("INSERT INTO runner_destinations(id,owner_id,runner_id,name,provider,rtmp_url,encrypted_stream_key) VALUES($1,$2,$3,'Scheduled loopback','custom','rtmp://127.0.0.1:1949/live',$4)", [target, world.owner.fixture.creatorId, world.runnerId, encryptString("disposable-schedule-key")]);
  415 | 		await pool.query("UPDATE stream_sessions SET control_mode='scheduled' WHERE id=$1", [world.sessionId]);
  416 | 		const startDate = new Date(Date.now() - 86400000).toISOString().slice(0, 10),
  417 | 			endDate = new Date(Date.now() + 86400000).toISOString().slice(0, 10),
  418 | 			currentId = randomUUID();
  419 | 		const entries = [
  420 | 			{ id: currentId, title: "Active window", timezone: "UTC", start: startDate, end: endDate, startTime: "00:00", endTime: "23:59" },
  421 | 			{ id: randomUUID(), title: "Future Berlin broadcast", timezone: "Europe/Berlin", start: date, end: date, startTime: "14:00", endTime: "16:00" },
  422 | 		];
  423 | 		for (const event of entries) {
  424 | 			await pool.query("INSERT INTO runner_schedule_events(id,owner_id,runner_id,session_id,overlay_id,title,timezone,recurrence,recurrence_anchor,local_start_date,local_end_date,local_start_time,local_end_time) VALUES($1,$2,$3,$4,$5,$6,$7,'once',$8,$8,$9,$10,$11)", [event.id, world.owner.fixture.creatorId, world.runnerId, world.sessionId, world.owner.fixture.overlayId, event.title, event.timezone, event.start, event.end, event.startTime, event.endTime]);
  425 | 			await pool.query("INSERT INTO runner_schedule_event_destinations(owner_id,event_id,destination_id,position) VALUES($1,$2,$3,0)", [world.owner.fixture.creatorId, event.id, target]);
  426 | 		}
  427 | 		await pool.query("UPDATE runner_broadcast_admissions SET occurrence_id=$2,scheduled_end=$3 WHERE session_id=$1", [world.sessionId, JSON.stringify([currentId, startDate]), `${endDate}T23:59:00Z`]);
  428 | 	} finally {
  429 | 		await pool.end();
  430 | 	}
  431 | });
  432 | Then("the optional next broadcast time matches preview and generated standby", async ({ page, mcpWorld }) => {
  433 | 	const choice = page.getByRole("switch", { name: "Show next broadcast time", exact: true });
> 434 | 	await expect(choice).toBeVisible();
      |                       ^ Error: expect(locator).toBeVisible() failed
  435 | 	await choice.focus();
  436 | 	await choice.press("Space");
  437 | 	await expect(choice).toBeChecked();
  438 | 	const expected = mcpWorld.input?.runnerStandbyNext as { expected: string; timezone: string };
  439 | 	const preview = page.frameLocator('iframe[title="Runner appearance preview"]').locator("[data-runner-next-broadcast]");
  440 | 	await expect(preview).toHaveAttribute("datetime", expected.expected);
  441 | 	await expect(preview).toHaveAttribute("data-timezone", expected.timezone);
  442 | 	await expect(preview).toContainText("14:00");
  443 | 	await page.getByRole("button", { name: "Save appearance", exact: true }).click();
  444 | 	await expect(page.getByRole("status").filter({ hasText: "Appearance saved" })).toBeVisible();
  445 | 	await page.reload();
  446 | 	await expect(choice).toBeChecked();
  447 | 	await expect(preview).toHaveAttribute("datetime", expected.expected);
  448 | 	const world = presentationState(mcpWorld.input);
  449 | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  450 | 	expect(response.status()).toBe(200);
  451 | 	const { url } = await response.json();
  452 | 	await page.goto(`http://127.0.0.1:3107${url}`);
  453 | 	const time = page.locator("[data-runner-next-broadcast]");
  454 | 	await expect(time).toHaveAttribute("datetime", expected.expected);
  455 | 	await expect(time).toHaveAttribute("data-timezone", expected.timezone);
  456 | 	await expect(time).toContainText("14:00");
  457 | });
  458 | 
```