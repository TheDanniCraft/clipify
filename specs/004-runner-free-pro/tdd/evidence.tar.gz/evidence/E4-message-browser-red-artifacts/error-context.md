# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: .features-gen/bdd/runner-standby.feature.spec.js >> Runner standby customization >> A Pro owner previews and saves a plain-text standby message
- Location: .features-gen/bdd/runner-standby.feature.spec.js:24:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByLabel('Standby message', { exact: true })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByLabel('Standby message', { exact: true }) with timeout 15000ms
  - waiting for getByLabel('Standby message', { exact: true })

```

```yaml
- button "Enable support chat"
- button "Report a problem":
  - img
  - text: Report a problem
- alert
- navigation:
  - link "Clipify":
    - /url: /dashboard
    - img
    - paragraph: Clipify
  - list:
    - listitem:
      - text: Account
      - group:
        - text: E2E Creator Account
        - button "E2E Creator Account Account context Account"
    - listitem:
      - button "Toggle Theme":
        - img
    - listitem:
      - button "Open profile menu":
        - text: E2
        - status "Online"
- main:
  - heading "Runner Settings" [level=1]
  - paragraph: Configure hardware streaming
  - button:
    - img
  - heading "Runner Settings" [level=1]
  - text: Streaming (LIVE)
  - button "Unlink runner" [disabled]:
    - img
  - separator
  - heading "Setup Your Runner" [level=2]
  - paragraph: This runner is linked to your account but is not connected yet. Download the runner for your operating system, run it, and approve the browser enrollment prompt. It will connect to this Clipify environment automatically.
  - button "Download for Windows":
    - img
    - text: Download for Windows
  - button "Download for Linux":
    - img
    - text: Download for Linux
  - button "Download for macOS":
    - img
    - text: Download for macOS
  - heading "Appearance" [level=2]
  - paragraph: Choose where Clipify attribution appears on generated content.
  - text: Standby logo
  - button "Standby logo"
  - text: PNG, JPEG or WebP, up to 2 MiB. Standby background image
  - button "Standby background image"
  - text: PNG, JPEG or WebP, up to 2 MiB. Standby background color
  - textbox "Standby background color": "#000000"
  - switch "Show Clipify attribution"
  - text: Show Clipify attribution Attribution corner
  - button "Bottom right Attribution corner": Bottom right
  - button "Save appearance"
  - iframe
  - heading "Broadcast schedule" [level=2]:
    - img
    - text: Broadcast schedule
  - paragraph: Plan one-time or weekly broadcasts. Your Runner computer must stay on.
  - button "Add schedule":
    - img
    - text: Add schedule
  - region "Broadcast calendar":
    - heading "Broadcast calendar" [level=3]
    - paragraph: Week view · Dates use UTC
    - text: Displayed date
    - textbox "Displayed date": 2026-10-17
    - text: Calendar timezone
    - combobox "Calendar timezone":
      - option "UTC" [selected]
    - button "Previous week": Previous
    - button "Today"
    - button "Next week": Next
    - text: Sun 11 Mon 12 Tue 13 Wed 14 Thu 15 Fri 16 Sat 17 1 AM 2 AM 3 AM 4 AM 5 AM 6 AM 7 AM 8 AM 9 AM 10 AM 11 AM 12 PM 1 PM 2 PM 3 PM 4 PM 5 PM 6 PM 7 PM 8 PM 9 PM 10 PM 11 PM
  - paragraph: No scheduled broadcasts yet.
  - heading "Destinations" [level=2]
  - paragraph: Save your streaming destinations and manage their protected keys.
  - button "Add destination":
    - img
    - text: Add destination
  - paragraph: No saved destinations yet.
```

# Test source

```ts
  286 | 	await expect(video).toHaveCount(1);
  287 | 	await expect.poll(() => video.evaluate((element) => (element as HTMLVideoElement).currentTime)).toBeGreaterThan(beforeTime);
  288 | });
  289 | 
  290 | Then("their standby background color matches draft preview and saved generated standby", async ({ page, mcpWorld }) => {
  291 | 	const color = page.getByLabel("Standby background color", { exact: true });
  292 | 	await expect(color).toBeVisible();
  293 | 	await color.fill("#16324f");
  294 | 	const standby = page.frameLocator('iframe[title="Runner appearance preview"]').locator("[data-runner-standby]");
  295 | 	await expect(standby).toHaveCSS("background-color", "rgb(22, 50, 79)");
  296 | 	await page.getByRole("button", { name: "Save appearance", exact: true }).click();
  297 | 	await expect(page.getByRole("status").filter({ hasText: "Appearance saved" })).toBeVisible();
  298 | 	await page.reload();
  299 | 	await expect(color).toHaveValue("#16324f");
  300 | 	await expect(standby).toHaveCSS("background-color", "rgb(22, 50, 79)");
  301 | 	const world = presentationState(mcpWorld.input);
  302 | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  303 | 	expect(response.status()).toBe(200);
  304 | 	const { url } = await response.json();
  305 | 	await page.goto(`http://127.0.0.1:3107${url}`);
  306 | 	await expect(page.locator("[data-runner-standby]")).toHaveCSS("background-color", "rgb(22, 50, 79)");
  307 | });
  308 | 
  309 | Then("their uploaded background image matches preview and saved generated standby", async ({ page, mcpWorld }) => {
  310 | 	const sharp = (await import("sharp")).default;
  311 | 	const bytes = await sharp({ create: { width: 16, height: 16, channels: 3, background: { r: 40, g: 120, b: 200 } } })
  312 | 		.png()
  313 | 		.toBuffer();
  314 | 	await page.getByLabel("Standby background image", { exact: true }).setInputFiles({ name: "standby.png", mimeType: "image/png", buffer: bytes });
  315 | 	const preview = page.frameLocator('iframe[title="Runner appearance preview"]').getByRole("img", { name: "Standby background", exact: true });
  316 | 	await expect(preview).toBeVisible();
  317 | 	await expect(preview).toHaveJSProperty("naturalWidth", 16);
  318 | 	await expect(preview).toHaveJSProperty("naturalHeight", 16);
  319 | 	await page.getByRole("button", { name: "Save appearance", exact: true }).click();
  320 | 	await expect(page.getByRole("status").filter({ hasText: "Appearance saved" })).toBeVisible();
  321 | 	await page.reload();
  322 | 	await expect(preview).toBeVisible();
  323 | 	await expect(preview).toHaveJSProperty("naturalWidth", 16);
  324 | 	const world = presentationState(mcpWorld.input);
  325 | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  326 | 	expect(response.status()).toBe(200);
  327 | 	const { url } = await response.json();
  328 | 	await page.goto(`http://127.0.0.1:3107${url}`);
  329 | 	const image = page.getByRole("img", { name: "Standby background", exact: true });
  330 | 	await expect(image).toBeVisible();
  331 | 	await expect(image).toHaveJSProperty("naturalWidth", 16);
  332 | 	await expect(image).toHaveJSProperty("naturalHeight", 16);
  333 | });
  334 | 
  335 | Then("their uploaded logo matches preview and saved generated standby", async ({ page, mcpWorld }) => {
  336 | 	const sharp = (await import("sharp")).default;
  337 | 	const bytes = await sharp({ create: { width: 16, height: 16, channels: 4, background: { r: 180, g: 40, b: 120, alpha: 0.8 } } })
  338 | 		.png()
  339 | 		.toBuffer();
  340 | 	const upload = page.getByLabel("Standby logo", { exact: true });
  341 | 	await expect(upload).toBeVisible();
  342 | 	await upload.setInputFiles({ name: "logo.png", mimeType: "image/png", buffer: bytes });
  343 | 	const preview = page.frameLocator('iframe[title="Runner appearance preview"]').getByRole("img", { name: "Standby logo", exact: true });
  344 | 	await expect(preview).toBeVisible();
  345 | 	await expect(preview).toHaveJSProperty("naturalWidth", 16);
  346 | 	await expect(preview).toHaveJSProperty("naturalHeight", 16);
  347 | 	await page.getByRole("button", { name: "Save appearance", exact: true }).click();
  348 | 	await expect(page.getByRole("status").filter({ hasText: "Appearance saved" })).toBeVisible();
  349 | 	await page.reload();
  350 | 	await expect(preview).toBeVisible();
  351 | 	await expect(preview).toHaveJSProperty("naturalWidth", 16);
  352 | 	const world = presentationState(mcpWorld.input);
  353 | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  354 | 	expect(response.status()).toBe(200);
  355 | 	const { url } = await response.json();
  356 | 	await page.goto(`http://127.0.0.1:3107${url}`);
  357 | 	const logo = page.getByRole("img", { name: "Standby logo", exact: true });
  358 | 	await expect(logo).toBeVisible();
  359 | 	await expect(logo).toHaveJSProperty("naturalWidth", 16);
  360 | 	await expect(logo).toHaveJSProperty("naturalHeight", 16);
  361 | 	const policy = await page.request.get(`http://127.0.0.1:3107/runner/presentation/${world.sessionId}/policy`);
  362 | 	expect(policy.status()).toBe(200);
  363 | 	expect(policy.headers()["cache-control"]).toBe("private, no-store");
  364 | 	const renewed = policy.headers()["set-cookie"] ?? "";
  365 | 	expect(renewed.includes("clipify_runner_presentation=")).toBe(true);
  366 | 	expect(renewed.includes(`Path=/runner/presentation/${world.sessionId}`)).toBe(true);
  367 | 	expect(/HttpOnly/i.test(renewed)).toBe(true);
  368 | 	expect(/Max-Age=600/i.test(renewed)).toBe(true);
  369 | 	expect(/SameSite=strict/i.test(renewed)).toBe(true);
  370 | });
  371 | 
  372 | Then("their standby message matches draft preview and the already active presentation", async ({ page, mcpWorld }) => {
  373 | 	const world = presentationState(mcpWorld.input);
  374 | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  375 | 	expect(response.status()).toBe(200);
  376 | 	const { url } = await response.json();
  377 | 	const output = await page.context().newPage();
  378 | 	try {
  379 | 		await output.clock.install({ time: Date.now() });
  380 | 		await output.goto(`http://127.0.0.1:3107${url}`);
  381 | 		await expect(output.locator("[data-runner-standby]")).toBeVisible();
  382 | 		const marker = await output.locator("[data-runner-content-phase]").elementHandle();
  383 | 		expect(marker).not.toBeNull();
  384 | 		const message = "Back soon <3 — thanks for watching!";
  385 | 		const editor = page.getByLabel("Standby message", { exact: true });
> 386 | 		await expect(editor).toBeVisible();
      |                        ^ Error: expect(locator).toBeVisible() failed
  387 | 		await editor.fill(message);
  388 | 		const preview = page.frameLocator('iframe[title="Runner appearance preview"]').getByText(message, { exact: true });
  389 | 		await expect(preview).toBeVisible();
  390 | 		await page.getByRole("button", { name: "Save appearance", exact: true }).click();
  391 | 		await expect(page.getByRole("status").filter({ hasText: "Appearance saved" })).toBeVisible();
  392 | 		await page.reload();
  393 | 		await expect(editor).toHaveValue(message);
  394 | 		await expect(preview).toBeVisible();
  395 | 		await output.clock.fastForward(30001);
  396 | 		await expect(output.getByText(message, { exact: true })).toBeVisible();
  397 | 		await expect(output.locator("[data-runner-presentation-generation]")).toHaveAttribute("data-runner-presentation-generation", world.generation);
  398 | 		expect(await marker!.evaluate((element) => element.isConnected)).toBe(true);
  399 | 	} finally {
  400 | 		await output.close();
  401 | 	}
  402 | });
  403 | 
```