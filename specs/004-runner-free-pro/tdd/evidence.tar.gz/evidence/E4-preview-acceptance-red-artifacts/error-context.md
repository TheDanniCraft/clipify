# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: .features-gen/atdd/runner-standby.feature.spec.js >> Review generated Runner appearance before broadcast >> Review custom standby at all four corners and in both preview modes
- Location: .features-gen/atdd/runner-standby.feature.spec.js:6:7

# Error details

```
Test timeout of 180000ms exceeded.
```

```
Error: locator.click: Test timeout of 180000ms exceeded.
Call log:
  - waiting for getByRole('button', { name: 'Preview standby', exact: true })

```

# Page snapshot

```yaml
- generic [active] [ref=f2e1]:
  - button "Enable support chat" [ref=f2e2] [cursor=pointer]
  - button "Report a problem" [ref=f2e3] [cursor=pointer]
  - alert [ref=f2e8]
  - navigation [ref=f2e9]:
    - generic [ref=f2e10]:
      - link [ref=f2e11] [cursor=pointer]:
        - /url: /dashboard
        - paragraph [ref=f2e16]: Clipify
      - list [ref=f2e17]:
        - listitem [ref=f2e18]:
          - generic [ref=f2e19]:
            - generic [ref=f2e20]: Account
            - group [ref=f2e21] [cursor=pointer]:
              - generic [ref=f2e25]: E2E Creator Account
              - button "E2E Creator Account Account context Account"
            - combobox [ref=f2e30]
        - listitem [ref=f2e31]:
          - button "Toggle Theme" [ref=f2e32] [cursor=pointer]
        - listitem [ref=f2e33]:
          - button "Open profile menu" [ref=f2e34] [cursor=pointer]:
            - generic [ref=f2e35]:
              - generic [ref=f2e36]: E2
              - status "Online" [ref=f2e38]
  - main [ref=f2e40]:
    - generic [ref=f2e41]:
      - generic [ref=f2e43]:
        - heading "Runner Settings" [level=1] [ref=f2e44]
        - paragraph [ref=f2e45]: Configure hardware streaming
      - generic [ref=f2e46]:
        - generic [ref=f2e47]:
          - generic [ref=f2e48]:
            - generic [ref=f2e49]:
              - button [ref=f2e50] [cursor=pointer]
              - heading "Runner Settings" [level=1] [ref=f2e51]
            - generic [ref=f2e53]:
              - generic [ref=f2e54]: Streaming (LIVE)
              - button "Unlink runner" [disabled]
          - separator [ref=f2e56]
          - generic [ref=f2e58]:
            - heading "Setup Your Runner" [level=2] [ref=f2e59]
            - paragraph [ref=f2e60]: This runner is linked to your account but is not connected yet. Download the runner for your operating system, run it, and approve the browser enrollment prompt. It will connect to this Clipify environment automatically.
            - generic [ref=f2e61]:
              - button "Download for Windows" [ref=f2e62] [cursor=pointer]
              - button "Download for Linux" [ref=f2e63] [cursor=pointer]
              - button "Download for macOS" [ref=f2e64] [cursor=pointer]
        - generic [ref=f2e65]:
          - generic [ref=f2e66]:
            - heading "Appearance" [level=2] [ref=f2e67]
            - paragraph [ref=f2e68]: Choose where Clipify attribution appears on generated content.
          - generic [ref=f2e69]:
            - generic [ref=f2e70]:
              - generic [ref=f2e71]:
                - text: Standby logo
                - button "Standby logo" [ref=f2e72]
                - generic [ref=f2e73]: PNG, JPEG or WebP, up to 2 MiB.
              - generic [ref=f2e74]:
                - text: Standby background image
                - button "Standby background image" [ref=f2e75]
                - generic [ref=f2e76]: PNG, JPEG or WebP, up to 2 MiB.
              - generic [ref=f2e77]:
                - text: Standby background color
                - textbox "Standby background color" [ref=f2e78] [cursor=pointer]: "#16324f"
              - generic [ref=f2e79]:
                - generic [ref=f2e80]: Standby message
                - textbox "Standby message" [ref=f2e81]: Back soon <3
                - generic [ref=f2e82]: 12/160 characters
              - generic [ref=f2e84] [cursor=pointer]:
                - switch "Show next broadcast time" [ref=f2e86]
                - generic [ref=f2e89]: Show next broadcast time
              - paragraph [ref=f2e90]: Shows the next scheduled broadcast in its saved timezone. Paused schedules stay hidden.
            - generic [ref=f2e92] [cursor=pointer]:
              - switch "Show Clipify attribution" [checked] [ref=f2e94]
              - generic [ref=f2e97]: Show Clipify attribution
            - generic [ref=f2e98]:
              - generic [ref=f2e99]: Attribution corner
              - button "Bottom right Attribution corner" [ref=f2e100] [cursor=pointer]:
                - generic [ref=f2e101]: Bottom right
              - combobox [ref=f2e106]
            - button "Save appearance" [ref=f2e107] [cursor=pointer]
            - iframe [ref=f2e109]:
              - generic [ref=f3e1]:
                - generic [ref=f3e2]:
                  - generic [ref=f3e3]:
                    - img "Standby background" [ref=f3e4]
                    - generic [ref=f3e5]:
                      - img "Standby logo" [ref=f3e6]
                      - paragraph [ref=f3e7]: Back soon <3
                  - complementary "Livestream powered by Clipify.us":
                    - generic:
                      - generic: Livestream powered
                      - generic: by Clipify.us
                - alert [ref=f3e8]
        - generic [ref=f2e110]:
          - generic [ref=f2e111]:
            - generic [ref=f2e112]:
              - heading "Broadcast schedule" [level=2] [ref=f2e113]
              - paragraph [ref=f2e117]: Plan one-time or weekly broadcasts. Your Runner computer must stay on.
            - button "Add schedule" [ref=f2e118] [cursor=pointer]
          - generic [ref=f2e119]:
            - region "Broadcast calendar" [ref=f2e120]:
              - generic [ref=f2e121]:
                - generic [ref=f2e122]:
                  - heading "Broadcast calendar" [level=3] [ref=f2e123]
                  - paragraph [ref=f2e124]: Week view · Dates use UTC
                - generic [ref=f2e125]:
                  - text: Displayed date
                  - textbox "Displayed date" [ref=f2e126]: 2026-10-18
                - generic [ref=f2e127]:
                  - text: Calendar timezone
                  - combobox "Calendar timezone" [ref=f2e128]:
                    - option "UTC" [selected]
                - generic [ref=f2e129]:
                  - button "Previous week" [ref=f2e130] [cursor=pointer]: Previous
                  - button "Today" [ref=f2e131] [cursor=pointer]
                  - button "Next week" [ref=f2e132] [cursor=pointer]: Next
              - generic [ref=f2e134]:
                - generic [ref=f2e135]:
                  - generic [ref=f2e136]:
                    - generic [ref=f2e137]: Sun
                    - generic [ref=f2e138]: "18"
                  - generic [ref=f2e139]:
                    - generic [ref=f2e140]: Mon
                    - generic [ref=f2e141]: "19"
                  - generic [ref=f2e142]:
                    - generic [ref=f2e143]: Tue
                    - generic [ref=f2e144]: "20"
                  - generic [ref=f2e145]:
                    - generic [ref=f2e146]: Wed
                    - generic [ref=f2e147]: "21"
                  - generic [ref=f2e148]:
                    - generic [ref=f2e149]: Thu
                    - generic [ref=f2e150]: "22"
                  - generic [ref=f2e151]:
                    - generic [ref=f2e152]: Fri
                    - generic [ref=f2e153]: "23"
                  - generic [ref=f2e154]:
                    - generic [ref=f2e155]: Sat
                    - generic [ref=f2e156]: "24"
                - generic [ref=f2e158]:
                  - generic [ref=f2e159]:
                    - generic [ref=f2e161]: 1 AM
                    - generic [ref=f2e163]: 2 AM
                    - generic [ref=f2e165]: 3 AM
                    - generic [ref=f2e167]: 4 AM
                    - generic [ref=f2e169]: 5 AM
                    - generic [ref=f2e171]: 6 AM
                    - generic [ref=f2e173]: 7 AM
                    - generic [ref=f2e175]: 8 AM
                    - generic [ref=f2e177]: 9 AM
                    - generic [ref=f2e179]: 10 AM
                    - generic [ref=f2e181]: 11 AM
                    - generic [ref=f2e183]: 12 PM
                    - generic [ref=f2e185]: 1 PM
                    - generic [ref=f2e187]: 2 PM
                    - generic [ref=f2e189]: 3 PM
                    - generic [ref=f2e191]: 4 PM
                    - generic [ref=f2e193]: 5 PM
                    - generic [ref=f2e195]: 6 PM
                    - generic [ref=f2e197]: 7 PM
                    - generic [ref=f2e199]: 8 PM
                    - generic [ref=f2e201]: 9 PM
                    - generic [ref=f2e203]: 10 PM
                    - generic [ref=f2e205]: 11 PM
                  - generic [ref=f2e207]:
                    - generic [ref=f2e208] [cursor=pointer]
                    - generic [ref=f2e209] [cursor=pointer]
                    - generic [ref=f2e210] [cursor=pointer]
                    - generic [ref=f2e211] [cursor=pointer]
                    - generic [ref=f2e212] [cursor=pointer]
                    - generic [ref=f2e213] [cursor=pointer]
                    - generic [ref=f2e214] [cursor=pointer]
                    - generic [ref=f2e215] [cursor=pointer]
                    - generic [ref=f2e216] [cursor=pointer]
                    - generic [ref=f2e217] [cursor=pointer]
                    - generic [ref=f2e218] [cursor=pointer]
                    - generic [ref=f2e219] [cursor=pointer]
                    - generic [ref=f2e220] [cursor=pointer]
                    - generic [ref=f2e221] [cursor=pointer]
                    - generic [ref=f2e222] [cursor=pointer]
                    - generic [ref=f2e223] [cursor=pointer]
                    - generic [ref=f2e224] [cursor=pointer]
                    - generic [ref=f2e225] [cursor=pointer]
                    - generic [ref=f2e226] [cursor=pointer]
                    - generic [ref=f2e227] [cursor=pointer]
                    - generic [ref=f2e228] [cursor=pointer]
                    - generic [ref=f2e229] [cursor=pointer]
                    - generic [ref=f2e230] [cursor=pointer]
                    - generic [ref=f2e231] [cursor=pointer]
                    - generic [ref=f2e232] [cursor=pointer]
                    - generic [ref=f2e233] [cursor=pointer]
                    - generic [ref=f2e234] [cursor=pointer]
                    - generic [ref=f2e235] [cursor=pointer]
                    - generic [ref=f2e236] [cursor=pointer]
                    - generic [ref=f2e237] [cursor=pointer]
                    - generic [ref=f2e238] [cursor=pointer]
                    - generic [ref=f2e239] [cursor=pointer]
                    - generic [ref=f2e240] [cursor=pointer]
                    - generic [ref=f2e241] [cursor=pointer]
                    - generic [ref=f2e242] [cursor=pointer]
                    - generic [ref=f2e243] [cursor=pointer]
                    - generic [ref=f2e244] [cursor=pointer]
                    - generic [ref=f2e245] [cursor=pointer]
                    - generic [ref=f2e246] [cursor=pointer]
                    - generic [ref=f2e247] [cursor=pointer]
                    - generic [ref=f2e248] [cursor=pointer]
                    - generic [ref=f2e249] [cursor=pointer]
                    - generic [ref=f2e250] [cursor=pointer]
                    - generic [ref=f2e251] [cursor=pointer]
                    - generic [ref=f2e252] [cursor=pointer]
                    - generic [ref=f2e253] [cursor=pointer]
                    - generic [ref=f2e254] [cursor=pointer]
                    - generic [ref=f2e255] [cursor=pointer]
                  - generic [ref=f2e256]:
                    - generic [ref=f2e257] [cursor=pointer]
                    - generic [ref=f2e258] [cursor=pointer]
                    - generic [ref=f2e259] [cursor=pointer]
                    - generic [ref=f2e260] [cursor=pointer]
                    - generic [ref=f2e261] [cursor=pointer]
                    - generic [ref=f2e262] [cursor=pointer]
                    - generic [ref=f2e263] [cursor=pointer]
                    - generic [ref=f2e264] [cursor=pointer]
                    - generic [ref=f2e265] [cursor=pointer]
                    - generic [ref=f2e266] [cursor=pointer]
                    - generic [ref=f2e267] [cursor=pointer]
                    - generic [ref=f2e268] [cursor=pointer]
                    - generic [ref=f2e269] [cursor=pointer]
                    - generic [ref=f2e270] [cursor=pointer]
                    - generic [ref=f2e271] [cursor=pointer]
                    - generic [ref=f2e272] [cursor=pointer]
                    - generic [ref=f2e273] [cursor=pointer]
                    - generic [ref=f2e274] [cursor=pointer]
                    - generic [ref=f2e275] [cursor=pointer]
                    - generic [ref=f2e276] [cursor=pointer]
                    - generic [ref=f2e277] [cursor=pointer]
                    - generic [ref=f2e278] [cursor=pointer]
                    - generic [ref=f2e279] [cursor=pointer]
                    - generic [ref=f2e280] [cursor=pointer]
                    - generic [ref=f2e281] [cursor=pointer]
                    - generic [ref=f2e282] [cursor=pointer]
                    - generic [ref=f2e283] [cursor=pointer]
                    - generic [ref=f2e284] [cursor=pointer]
                    - generic [ref=f2e285] [cursor=pointer]
                    - generic [ref=f2e286] [cursor=pointer]
                    - generic [ref=f2e287] [cursor=pointer]
                    - generic [ref=f2e288] [cursor=pointer]
                    - generic [ref=f2e289] [cursor=pointer]
                    - generic [ref=f2e290] [cursor=pointer]
                    - generic [ref=f2e291] [cursor=pointer]
                    - generic [ref=f2e292] [cursor=pointer]
                    - generic [ref=f2e293] [cursor=pointer]
                    - generic [ref=f2e294] [cursor=pointer]
                    - generic [ref=f2e295] [cursor=pointer]
                    - generic [ref=f2e296] [cursor=pointer]
                    - generic [ref=f2e297] [cursor=pointer]
                    - generic [ref=f2e298] [cursor=pointer]
                    - generic [ref=f2e299] [cursor=pointer]
                    - generic [ref=f2e300] [cursor=pointer]
                    - generic [ref=f2e301] [cursor=pointer]
                    - generic [ref=f2e302] [cursor=pointer]
                    - generic [ref=f2e303] [cursor=pointer]
                    - generic [ref=f2e304] [cursor=pointer]
                  - generic [ref=f2e305]:
                    - generic [ref=f2e306] [cursor=pointer]
                    - generic [ref=f2e307] [cursor=pointer]
                    - generic [ref=f2e308] [cursor=pointer]
                    - generic [ref=f2e309] [cursor=pointer]
                    - generic [ref=f2e310] [cursor=pointer]
                    - generic [ref=f2e311] [cursor=pointer]
                    - generic [ref=f2e312] [cursor=pointer]
                    - generic [ref=f2e313] [cursor=pointer]
                    - generic [ref=f2e314] [cursor=pointer]
                    - generic [ref=f2e315] [cursor=pointer]
                    - generic [ref=f2e316] [cursor=pointer]
                    - generic [ref=f2e317] [cursor=pointer]
                    - generic [ref=f2e318] [cursor=pointer]
                    - generic [ref=f2e319] [cursor=pointer]
                    - generic [ref=f2e320] [cursor=pointer]
                    - generic [ref=f2e321] [cursor=pointer]
                    - generic [ref=f2e322] [cursor=pointer]
                    - generic [ref=f2e323] [cursor=pointer]
                    - generic [ref=f2e324] [cursor=pointer]
                    - generic [ref=f2e325] [cursor=pointer]
                    - generic [ref=f2e326] [cursor=pointer]
                    - generic [ref=f2e327] [cursor=pointer]
                    - generic [ref=f2e328] [cursor=pointer]
                    - generic [ref=f2e329] [cursor=pointer]
                    - generic [ref=f2e330] [cursor=pointer]
                    - generic [ref=f2e331] [cursor=pointer]
                    - generic [ref=f2e332] [cursor=pointer]
                    - generic [ref=f2e333] [cursor=pointer]
                    - generic [ref=f2e334] [cursor=pointer]
                    - generic [ref=f2e335] [cursor=pointer]
                    - generic [ref=f2e336] [cursor=pointer]
                    - generic [ref=f2e337] [cursor=pointer]
                    - generic [ref=f2e338] [cursor=pointer]
                    - generic [ref=f2e339] [cursor=pointer]
                    - generic [ref=f2e340] [cursor=pointer]
                    - generic [ref=f2e341] [cursor=pointer]
                    - generic [ref=f2e342] [cursor=pointer]
                    - generic [ref=f2e343] [cursor=pointer]
                    - generic [ref=f2e344] [cursor=pointer]
                    - generic [ref=f2e345] [cursor=pointer]
                    - generic [ref=f2e346] [cursor=pointer]
                    - generic [ref=f2e347] [cursor=pointer]
                    - generic [ref=f2e348] [cursor=pointer]
                    - generic [ref=f2e349] [cursor=pointer]
                    - generic [ref=f2e350] [cursor=pointer]
                    - generic [ref=f2e351] [cursor=pointer]
                    - generic [ref=f2e352] [cursor=pointer]
                    - generic [ref=f2e353] [cursor=pointer]
                  - generic [ref=f2e354]:
                    - generic [ref=f2e355] [cursor=pointer]
                    - generic [ref=f2e356] [cursor=pointer]
                    - generic [ref=f2e357] [cursor=pointer]
                    - generic [ref=f2e358] [cursor=pointer]
                    - generic [ref=f2e359] [cursor=pointer]
                    - generic [ref=f2e360] [cursor=pointer]
                    - generic [ref=f2e361] [cursor=pointer]
                    - generic [ref=f2e362] [cursor=pointer]
                    - generic [ref=f2e363] [cursor=pointer]
                    - generic [ref=f2e364] [cursor=pointer]
                    - generic [ref=f2e365] [cursor=pointer]
                    - generic [ref=f2e366] [cursor=pointer]
                    - generic [ref=f2e367] [cursor=pointer]
                    - generic [ref=f2e368] [cursor=pointer]
                    - generic [ref=f2e369] [cursor=pointer]
                    - generic [ref=f2e370] [cursor=pointer]
                    - generic [ref=f2e371] [cursor=pointer]
                    - generic [ref=f2e372] [cursor=pointer]
                    - generic [ref=f2e373] [cursor=pointer]
                    - generic [ref=f2e374] [cursor=pointer]
                    - generic [ref=f2e375] [cursor=pointer]
                    - generic [ref=f2e376] [cursor=pointer]
                    - generic [ref=f2e377] [cursor=pointer]
                    - generic [ref=f2e378] [cursor=pointer]
                    - generic [ref=f2e379] [cursor=pointer]
                    - generic [ref=f2e380] [cursor=pointer]
                    - generic [ref=f2e381] [cursor=pointer]
                    - generic [ref=f2e382] [cursor=pointer]
                    - generic [ref=f2e383] [cursor=pointer]
                    - generic [ref=f2e384] [cursor=pointer]
                    - generic [ref=f2e385] [cursor=pointer]
                    - generic [ref=f2e386] [cursor=pointer]
                    - generic [ref=f2e387] [cursor=pointer]
                    - generic [ref=f2e388] [cursor=pointer]
                    - generic [ref=f2e389] [cursor=pointer]
                    - generic [ref=f2e390] [cursor=pointer]
                    - generic [ref=f2e391] [cursor=pointer]
                    - generic [ref=f2e392] [cursor=pointer]
                    - generic [ref=f2e393] [cursor=pointer]
                    - generic [ref=f2e394] [cursor=pointer]
                    - generic [ref=f2e395] [cursor=pointer]
                    - generic [ref=f2e396] [cursor=pointer]
                    - generic [ref=f2e397] [cursor=pointer]
                    - generic [ref=f2e398] [cursor=pointer]
                    - generic [ref=f2e399] [cursor=pointer]
                    - generic [ref=f2e400] [cursor=pointer]
                    - generic [ref=f2e401] [cursor=pointer]
                    - generic [ref=f2e402] [cursor=pointer]
                  - generic [ref=f2e403]:
                    - generic [ref=f2e404] [cursor=pointer]
                    - generic [ref=f2e405] [cursor=pointer]
                    - generic [ref=f2e406] [cursor=pointer]
                    - generic [ref=f2e407] [cursor=pointer]
                    - generic [ref=f2e408] [cursor=pointer]
                    - generic [ref=f2e409] [cursor=pointer]
                    - generic [ref=f2e410] [cursor=pointer]
                    - generic [ref=f2e411] [cursor=pointer]
                    - generic [ref=f2e412] [cursor=pointer]
                    - generic [ref=f2e413] [cursor=pointer]
                    - generic [ref=f2e414] [cursor=pointer]
                    - generic [ref=f2e415] [cursor=pointer]
                    - generic [ref=f2e416] [cursor=pointer]
                    - generic [ref=f2e417] [cursor=pointer]
                    - generic [ref=f2e418] [cursor=pointer]
                    - generic [ref=f2e419] [cursor=pointer]
                    - generic [ref=f2e420] [cursor=pointer]
                    - generic [ref=f2e421] [cursor=pointer]
                    - generic [ref=f2e422] [cursor=pointer]
                    - generic [ref=f2e423] [cursor=pointer]
                    - generic [ref=f2e424] [cursor=pointer]
                    - generic [ref=f2e425] [cursor=pointer]
                    - generic [ref=f2e426] [cursor=pointer]
                    - generic [ref=f2e427] [cursor=pointer]
                    - generic [ref=f2e428] [cursor=pointer]
                    - generic [ref=f2e429] [cursor=pointer]
                    - generic [ref=f2e430] [cursor=pointer]
                    - generic [ref=f2e431] [cursor=pointer]
                    - generic [ref=f2e432] [cursor=pointer]
                    - generic [ref=f2e433] [cursor=pointer]
                    - generic [ref=f2e434] [cursor=pointer]
                    - generic [ref=f2e435] [cursor=pointer]
                    - generic [ref=f2e436] [cursor=pointer]
                    - generic [ref=f2e437] [cursor=pointer]
                    - generic [ref=f2e438] [cursor=pointer]
                    - generic [ref=f2e439] [cursor=pointer]
                    - generic [ref=f2e440] [cursor=pointer]
                    - generic [ref=f2e441] [cursor=pointer]
                    - generic [ref=f2e442] [cursor=pointer]
                    - generic [ref=f2e443] [cursor=pointer]
                    - generic [ref=f2e444] [cursor=pointer]
                    - generic [ref=f2e445] [cursor=pointer]
                    - generic [ref=f2e446] [cursor=pointer]
                    - generic [ref=f2e447] [cursor=pointer]
                    - generic [ref=f2e448] [cursor=pointer]
                    - generic [ref=f2e449] [cursor=pointer]
                    - generic [ref=f2e450] [cursor=pointer]
                    - generic [ref=f2e451] [cursor=pointer]
                  - generic [ref=f2e452]:
                    - generic [ref=f2e453] [cursor=pointer]
                    - generic [ref=f2e454] [cursor=pointer]
                    - generic [ref=f2e455] [cursor=pointer]
                    - generic [ref=f2e456] [cursor=pointer]
                    - generic [ref=f2e457] [cursor=pointer]
                    - generic [ref=f2e458] [cursor=pointer]
                    - generic [ref=f2e459] [cursor=pointer]
                    - generic [ref=f2e460] [cursor=pointer]
                    - generic [ref=f2e461] [cursor=pointer]
                    - generic [ref=f2e462] [cursor=pointer]
                    - generic [ref=f2e463] [cursor=pointer]
                    - generic [ref=f2e464] [cursor=pointer]
                    - generic [ref=f2e465] [cursor=pointer]
                    - generic [ref=f2e466] [cursor=pointer]
                    - generic [ref=f2e467] [cursor=pointer]
                    - generic [ref=f2e468] [cursor=pointer]
                    - generic [ref=f2e469] [cursor=pointer]
                    - generic [ref=f2e470] [cursor=pointer]
                    - generic [ref=f2e471] [cursor=pointer]
                    - generic [ref=f2e472] [cursor=pointer]
                    - generic [ref=f2e473] [cursor=pointer]
                    - generic [ref=f2e474] [cursor=pointer]
                    - generic [ref=f2e475] [cursor=pointer]
                    - generic [ref=f2e476] [cursor=pointer]
                    - generic [ref=f2e477] [cursor=pointer]
                    - generic [ref=f2e478] [cursor=pointer]
                    - generic [ref=f2e479] [cursor=pointer]
                    - generic [ref=f2e480] [cursor=pointer]
                    - generic [ref=f2e481] [cursor=pointer]
                    - generic [ref=f2e482] [cursor=pointer]
                    - generic [ref=f2e483] [cursor=pointer]
                    - generic [ref=f2e484] [cursor=pointer]
                    - generic [ref=f2e485] [cursor=pointer]
                    - generic [ref=f2e486] [cursor=pointer]
                    - generic [ref=f2e487] [cursor=pointer]
                    - generic [ref=f2e488] [cursor=pointer]
                    - generic [ref=f2e489] [cursor=pointer]
                    - generic [ref=f2e490] [cursor=pointer]
                    - generic [ref=f2e491] [cursor=pointer]
                    - generic [ref=f2e492] [cursor=pointer]
                    - generic [ref=f2e493] [cursor=pointer]
                    - generic [ref=f2e494] [cursor=pointer]
                    - generic [ref=f2e495] [cursor=pointer]
                    - generic [ref=f2e496] [cursor=pointer]
                    - generic [ref=f2e497] [cursor=pointer]
                    - generic [ref=f2e498] [cursor=pointer]
                    - generic [ref=f2e499] [cursor=pointer]
                    - generic [ref=f2e500] [cursor=pointer]
                  - generic [ref=f2e501]:
                    - generic [ref=f2e502] [cursor=pointer]
                    - generic [ref=f2e503] [cursor=pointer]
                    - generic [ref=f2e504] [cursor=pointer]
                    - generic [ref=f2e505] [cursor=pointer]
                    - generic [ref=f2e506] [cursor=pointer]
                    - generic [ref=f2e507] [cursor=pointer]
                    - generic [ref=f2e508] [cursor=pointer]
                    - generic [ref=f2e509] [cursor=pointer]
                    - generic [ref=f2e510] [cursor=pointer]
                    - generic [ref=f2e511] [cursor=pointer]
                    - generic [ref=f2e512] [cursor=pointer]
                    - generic [ref=f2e513] [cursor=pointer]
                    - generic [ref=f2e514] [cursor=pointer]
                    - generic [ref=f2e515] [cursor=pointer]
                    - generic [ref=f2e516] [cursor=pointer]
                    - generic [ref=f2e517] [cursor=pointer]
                    - generic [ref=f2e518] [cursor=pointer]
                    - generic [ref=f2e519] [cursor=pointer]
                    - generic [ref=f2e520] [cursor=pointer]
                    - generic [ref=f2e521] [cursor=pointer]
                    - generic [ref=f2e522] [cursor=pointer]
                    - generic [ref=f2e523] [cursor=pointer]
                    - generic [ref=f2e524] [cursor=pointer]
                    - generic [ref=f2e525] [cursor=pointer]
                    - generic [ref=f2e526] [cursor=pointer]
                    - generic [ref=f2e527] [cursor=pointer]
                    - generic [ref=f2e528] [cursor=pointer]
                    - generic [ref=f2e529] [cursor=pointer]
                    - generic [ref=f2e530] [cursor=pointer]
                    - generic [ref=f2e531] [cursor=pointer]
                    - generic [ref=f2e532] [cursor=pointer]
                    - generic [ref=f2e533] [cursor=pointer]
                    - generic [ref=f2e534] [cursor=pointer]
                    - generic [ref=f2e535] [cursor=pointer]
                    - generic [ref=f2e536] [cursor=pointer]
                    - generic [ref=f2e537] [cursor=pointer]
                    - generic [ref=f2e538] [cursor=pointer]
                    - generic [ref=f2e539] [cursor=pointer]
                    - generic [ref=f2e540] [cursor=pointer]
                    - generic [ref=f2e541] [cursor=pointer]
                    - generic [ref=f2e542] [cursor=pointer]
                    - generic [ref=f2e543] [cursor=pointer]
                    - generic [ref=f2e544] [cursor=pointer]
                    - generic [ref=f2e545] [cursor=pointer]
                    - generic [ref=f2e546] [cursor=pointer]
                    - generic [ref=f2e547] [cursor=pointer]
                    - generic [ref=f2e548] [cursor=pointer]
                    - generic [ref=f2e549] [cursor=pointer]
            - paragraph [ref=f2e550]: No scheduled broadcasts yet.
        - generic [ref=f2e551]:
          - generic [ref=f2e552]:
            - generic [ref=f2e553]:
              - heading "Destinations" [level=2] [ref=f2e554]
              - paragraph [ref=f2e555]: Save your streaming destinations and manage their protected keys.
            - button "Add destination" [ref=f2e556] [cursor=pointer]
          - paragraph [ref=f2e558]: No saved destinations yet.
```

# Test source

```ts
  1   | import { createBdd } from "playwright-bdd";
  2   | import { randomUUID, createHash } from "node:crypto";
  3   | import { Pool } from "pg";
  4   | import { test, expect } from "../support/runner-free-pro";
  5   | import { preparePresentationFixture, state, fixtureHeaders } from "../../bdd/support/runner-presentation";
  6   | import { browserDatabaseUrl } from "../../support/mcp/browser-database.cjs";
  7   | const { Given, When, Then, AfterScenario } = createBdd(test);
  8   | Given("a Pro creator has a saved custom standby and a playable generated source", async ({ request, page, mcpWorld }) => {
  9   | 	await preparePresentationFixture(request, mcpWorld, true);
  10  | 	const world = state(mcpWorld.input);
  11  | 	const sharp = (await import("sharp")).default;
  12  | 	const pool = new Pool({ connectionString: browserDatabaseUrl(), max: 1 });
  13  | 	const logoId = randomUUID(),
  14  | 		backgroundId = randomUUID();
  15  | 	try {
  16  | 		await pool.query("UPDATE users SET plan='pro' WHERE id=$1", [world.owner.fixture.creatorId]);
  17  | 		await pool.query("UPDATE runner_broadcast_admissions SET benefits_at_start=benefits_at_start || '{\"runnerPro\":true}'::jsonb WHERE session_id=$1", [world.sessionId]);
  18  | 		for (const asset of [
  19  | 			{ id: logoId, kind: "logo", color: { r: 180, g: 40, b: 120 } },
  20  | 			{ id: backgroundId, kind: "background", color: { r: 20, g: 60, b: 90 } },
  21  | 		]) {
  22  | 			const bytes = await sharp({ create: { width: 32, height: 32, channels: 3, background: asset.color } })
  23  | 				.png()
  24  | 				.toBuffer();
  25  | 			await pool.query("INSERT INTO runner_branding_assets(id,owner_id,kind,normalized_mime,size_bytes,width,height,checksum,bytes) VALUES($1,$2,$3,'image/png',$4,32,32,$5,$6)", [asset.id, world.owner.fixture.creatorId, asset.kind, bytes.length, createHash("sha256").update(bytes).digest("hex"), bytes]);
  26  | 		}
  27  | 		await pool.query("INSERT INTO runner_branding_profiles(owner_id,runner_id,watermark_corner,pro_show_attribution,standby_background_color,logo_asset_id,background_asset_id,message) VALUES($1,$2,'bottom_right',true,'#16324f',$3,$4,'Back soon <3')", [world.owner.fixture.creatorId, world.runnerId, logoId, backgroundId]);
  28  | 	} finally {
  29  | 		await pool.end();
  30  | 	}
  31  | 	await page.context().addCookies([world.owner.cookie]);
  32  | 	await page.goto("http://127.0.0.1:3107/legal/cookies");
  33  | 	await expect(page.getByRole("button", { name: "Enable support chat", exact: true })).toBeVisible();
  34  | 	const preferences = page.getByRole("main").getByRole("button", { name: "Cookie preferences", exact: true });
  35  | 	await preferences.focus();
  36  | 	await preferences.press("Enter");
  37  | 	const privacy = page.getByRole("dialog", { name: "Privacy preferences", exact: true });
  38  | 	await expect(privacy).toBeVisible();
  39  | 	await Promise.all([page.waitForEvent("load"), privacy.getByRole("button", { name: "Reject optional", exact: true }).click()]);
  40  | 	await page.goto(`http://127.0.0.1:3107/dashboard/runners/${world.runnerId}`);
  41  | 	await expect(page.getByTitle("Runner appearance preview")).toBeVisible();
  42  | });
  43  | When("they review real standby and clip previews at all four attribution corners", async ({ page }) => {
> 44  | 	await page.getByRole("button", { name: "Preview standby", exact: true }).click();
      |                                                                           ^ Error: locator.click: Test timeout of 180000ms exceeded.
  45  | 	const preview = page.frameLocator('iframe[title="Runner appearance preview"]');
  46  | 	await expect(preview.getByRole("img", { name: "Standby logo", exact: true })).toBeVisible();
  47  | 	await expect(preview.getByText("Back soon <3", { exact: true })).toBeVisible();
  48  | 	for (const corner of [
  49  | 		{ label: "Top left", right: false, bottom: false },
  50  | 		{ label: "Top right", right: true, bottom: false },
  51  | 		{ label: "Bottom left", right: false, bottom: true },
  52  | 		{ label: "Bottom right", right: true, bottom: true },
  53  | 	]) {
  54  | 		await page.getByRole("button", { name: /Attribution corner$/ }).click();
  55  | 		await page.getByRole("option", { name: corner.label, exact: true }).click();
  56  | 		const badge = preview.getByLabel("Livestream powered by Clipify.us", { exact: true });
  57  | 		await expect(badge).toBeVisible();
  58  | 		await expect
  59  | 			.poll(() =>
  60  | 				badge.evaluate((element) => {
  61  | 					const box = element.getBoundingClientRect();
  62  | 					return { left: box.left, right: innerWidth - box.right, top: box.top, bottom: innerHeight - box.bottom, scale: innerHeight / 1080 };
  63  | 				}),
  64  | 			)
  65  | 			.toMatchObject({ scale: expect.any(Number) });
  66  | 		const geometry = await badge.evaluate((element) => {
  67  | 			const box = element.getBoundingClientRect();
  68  | 			return { left: box.left, right: innerWidth - box.right, top: box.top, bottom: innerHeight - box.bottom, scale: innerHeight / 1080 };
  69  | 		});
  70  | 		expect(corner.right ? geometry.right : geometry.left).toBeCloseTo(24 * geometry.scale, 0);
  71  | 		expect(corner.bottom ? geometry.bottom : geometry.top).toBeCloseTo(24 * geometry.scale, 0);
  72  | 	}
  73  | 	await page.getByRole("button", { name: "Preview clips", exact: true }).click();
  74  | 	await expect
  75  | 		.poll(() =>
  76  | 			preview
  77  | 				.locator("video")
  78  | 				.first()
  79  | 				.evaluate((video) => (video as HTMLVideoElement).currentTime),
  80  | 		)
  81  | 		.toBeGreaterThan(0.2);
  82  | 	await expect(preview.locator("[data-runner-standby]")).toHaveCount(0);
  83  | 	await page.getByRole("button", { name: "Preview standby", exact: true }).click();
  84  | 	await expect(preview.locator("[data-runner-standby]")).toBeVisible();
  85  | });
  86  | Then("clearing optional images previews the saved color and message before applying them", async ({ page, mcpWorld }) => {
  87  | 	const preview = page.frameLocator('iframe[title="Runner appearance preview"]');
  88  | 	await page.getByRole("button", { name: "Remove logo", exact: true }).click();
  89  | 	await page.getByRole("button", { name: "Remove background image", exact: true }).click();
  90  | 	await expect(preview.getByRole("img", { name: "Standby logo", exact: true })).toHaveCount(0);
  91  | 	await expect(preview.getByRole("img", { name: "Standby background", exact: true })).toHaveCount(0);
  92  | 	await expect(preview.locator("[data-runner-standby]")).toHaveCSS("background-color", "rgb(22, 50, 79)");
  93  | 	await expect(preview.getByText("Back soon <3", { exact: true })).toBeVisible();
  94  | 	await page.getByRole("button", { name: "Save appearance", exact: true }).click();
  95  | 	await expect(page.getByRole("status").filter({ hasText: "Appearance saved" })).toBeVisible();
  96  | 	const world = state(mcpWorld.input);
  97  | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  98  | 	expect(response.status()).toBe(200);
  99  | 	const { url } = await response.json();
  100 | 	await page.goto(`http://127.0.0.1:3107${url}`);
  101 | 	await expect(page.locator("[data-runner-standby]")).toHaveCSS("background-color", "rgb(22, 50, 79)");
  102 | 	await expect(page.getByText("Back soon <3", { exact: true })).toBeVisible();
  103 | 	await expect(page.getByRole("img", { name: "Standby logo", exact: true })).toHaveCount(0);
  104 | 	await expect(page.getByRole("img", { name: "Standby background", exact: true })).toHaveCount(0);
  105 | 	await expect(page.getByLabel("Livestream powered by Clipify.us", { exact: true })).toBeVisible();
  106 | });
  107 | AfterScenario({ tags: "@runner-standby-acceptance" }, async ({ request, mcpWorld }) => {
  108 | 	const world = state(mcpWorld.input);
  109 | 	if (!world) return;
  110 | 	const fixture = world.owner.fixture;
  111 | 	const response = await request.delete("http://127.0.0.1:3107/api/test/auth-fixture", { headers: fixtureHeaders, data: { authUserId: fixture.authUserId, creatorId: fixture.creatorId, organizationIds: [fixture.creatorOrganizationId, fixture.agencyOrganizationId] } });
  112 | 	expect(response.status()).toBe(204);
  113 | });
  114 | 
```