# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: .features-gen/bdd/runner-free-pro.feature.spec.js >> Manual Runner configuration >> A Pro owner previews and saves a standby background color
- Location: .features-gen/bdd/runner-free-pro.feature.spec.js:307:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: getByLabel('Standby background color', { exact: true })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" getByLabel('Standby background color', { exact: true }) with timeout 15000ms
  - waiting for getByLabel('Standby background color', { exact: true })

```

```yaml
- button "Enable support chat"
- button "Report a problem":
  - img
  - text: Report a problem
- alert
- navigation:
  - link "Clipify":
    - /url: /dashboard
    - img
    - paragraph: Clipify
  - list:
    - listitem:
      - text: Account
      - group:
        - text: E2E Creator Account
        - button "E2E Creator Account Account context Account"
    - listitem:
      - button "Toggle Theme":
        - img
    - listitem:
      - button "Open profile menu":
        - text: E2
        - status "Online"
- main:
  - heading "Runner Settings" [level=1]
  - paragraph: Configure hardware streaming
  - button:
    - img
  - heading "Runner Settings" [level=1]
  - text: Streaming (LIVE)
  - button "Unlink runner" [disabled]:
    - img
  - separator
  - heading "Setup Your Runner" [level=2]
  - paragraph: This runner is linked to your account but is not connected yet. Download the runner for your operating system, run it, and approve the browser enrollment prompt. It will connect to this Clipify environment automatically.
  - button "Download for Windows":
    - img
    - text: Download for Windows
  - button "Download for Linux":
    - img
    - text: Download for Linux
  - button "Download for macOS":
    - img
    - text: Download for macOS
  - heading "Appearance" [level=2]
  - paragraph: Choose where Clipify attribution appears on generated content.
  - switch "Show Clipify attribution"
  - text: Show Clipify attribution Attribution corner
  - button "Bottom right Attribution corner": Bottom right
  - button "Save appearance"
  - iframe
  - heading "Broadcast schedule" [level=2]:
    - img
    - text: Broadcast schedule
  - paragraph: Plan one-time or weekly broadcasts. Your Runner computer must stay on.
  - button "Add schedule":
    - img
    - text: Add schedule
  - region "Broadcast calendar":
    - heading "Broadcast calendar" [level=3]
    - paragraph: Week view · Dates use UTC
    - text: Displayed date
    - textbox "Displayed date": 2026-10-17
    - text: Calendar timezone
    - combobox "Calendar timezone":
      - option "UTC" [selected]
    - button "Previous week": Previous
    - button "Today"
    - button "Next week": Next
    - text: Sun 11 Mon 12 Tue 13 Wed 14 Thu 15 Fri 16 Sat 17 1 AM 2 AM 3 AM 4 AM 5 AM 6 AM 7 AM 8 AM 9 AM 10 AM 11 AM 12 PM 1 PM 2 PM 3 PM 4 PM 5 PM 6 PM 7 PM 8 PM 9 PM 10 PM 11 PM
  - paragraph: No scheduled broadcasts yet.
  - heading "Destinations" [level=2]
  - paragraph: Save your streaming destinations and manage their protected keys.
  - button "Add destination":
    - img
    - text: Add destination
  - paragraph: No saved destinations yet.
```

# Test source

```ts
  192 | 	expect(response.status()).toBe(200);
  193 | 	const { url } = await response.json();
  194 | 	await page.goto(`http://127.0.0.1:3107${url}`);
  195 | 	await page.waitForFunction(() => typeof (window as Window & { startRunnerPlayback?: () => void }).startRunnerPlayback === "function");
  196 | 	await page.evaluate(() => (window as Window & { startRunnerPlayback?: () => void }).startRunnerPlayback?.());
  197 | 	await expect
  198 | 		.poll(() =>
  199 | 			page
  200 | 				.locator("video")
  201 | 				.first()
  202 | 				.evaluate((video) => (video as HTMLVideoElement).currentTime),
  203 | 		)
  204 | 		.toBeGreaterThan(0.2);
  205 | 	await expect(page.locator("[data-runner-presentation-generation]")).toHaveAttribute("data-runner-layout-status", enabled ? "placed" : "clean");
  206 | 	await expect(page.locator("[data-runner-attribution]")).toHaveCount(enabled ? 1 : 0);
  207 | }
  208 | 
  209 | Then("choosing branding off persists clean preview and generated playback", async ({ page, mcpWorld }) => verifySavedAttribution(page, mcpWorld, false));
  210 | 
  211 | Then("choosing branding on persists branded preview and generated playback", async ({ page, mcpWorld }) => verifySavedAttribution(page, mcpWorld, true));
  212 | 
  213 | When("its admitted paid deadline is reached during generated playback", async ({ page, mcpWorld }) => {
  214 | 	const world = presentationState(mcpWorld.input);
  215 | 	const deadline = Date.now() + 20000;
  216 | 	const pool = new Pool({ connectionString: browserDatabaseUrl(), max: 1 });
  217 | 	try {
  218 | 		await pool.query("UPDATE users SET plan='free' WHERE id=$1", [world.owner.fixture.creatorId]);
  219 | 		await pool.query("INSERT INTO entitlement_grants(user_id,entitlement,source,starts_at,ends_at) VALUES($1,'pro_access','reverse_trial',now()-interval '1 hour',$2)", [world.owner.fixture.creatorId, new Date(deadline)]);
  220 | 		await pool.query("UPDATE runner_broadcast_admissions SET benefits_at_start=benefits_at_start || $2::jsonb WHERE session_id=$1", [world.sessionId, JSON.stringify({ runnerPro: true, validUntil: new Date(deadline).toISOString() })]);
  221 | 		await pool.query("INSERT INTO runner_branding_profiles(owner_id,runner_id,watermark_corner,pro_show_attribution) VALUES($1,$2,'top_left',false)", [world.owner.fixture.creatorId, world.runnerId]);
  222 | 	} finally {
  223 | 		await pool.end();
  224 | 	}
  225 | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  226 | 	expect(response.status()).toBe(200);
  227 | 	const { url } = await response.json();
  228 | 	await page.goto(`http://127.0.0.1:3107${url}`);
  229 | 	await page.waitForFunction(() => typeof (window as Window & { startRunnerPlayback?: () => void }).startRunnerPlayback === "function");
  230 | 	await page.evaluate(() => (window as Window & { startRunnerPlayback?: () => void }).startRunnerPlayback?.());
  231 | 	const video = page.locator("video").first();
  232 | 	await expect.poll(() => video.evaluate((element) => (element as HTMLVideoElement).currentTime)).toBeGreaterThan(0.2);
  233 | 	await expect(page.locator("[data-runner-presentation-generation]")).toHaveAttribute("data-runner-layout-status", "clean");
  234 | 	await expect(page.locator("[data-runner-attribution]")).toHaveCount(0);
  235 | 	expect(Date.now(), "Fixture must still be paid before the observed transition").toBeLessThan(deadline);
  236 | 	const beforeTime = await video.evaluate((element, marker) => {
  237 | 		(element as HTMLVideoElement).dataset.expiryContinuity = marker;
  238 | 		return (element as HTMLVideoElement).currentTime;
  239 | 	}, world.generation);
  240 | 	mcpWorld.input = { ...mcpWorld.input, runnerPresentationExpiry: { deadline, beforeTime } };
  241 | });
  242 | 
  243 | Then("required branding returns while its original clip and execution keep running", async ({ page, mcpWorld }) => {
  244 | 	const world = presentationState(mcpWorld.input);
  245 | 	const { deadline, beforeTime } = mcpWorld.input!.runnerPresentationExpiry as { deadline: number; beforeTime: number };
  246 | 	await expect(page.getByLabel("Livestream powered by Clipify.us", { exact: true })).toBeVisible({ timeout: Math.max(0, deadline - Date.now()) + 5000 });
  247 | 	await expect(page.locator("[data-runner-presentation-generation]")).toHaveAttribute("data-runner-presentation-generation", world.generation);
  248 | 	const originalVideo = page.locator(`video[data-expiry-continuity="${world.generation}"]`);
  249 | 	await expect(originalVideo).toHaveCount(1);
  250 | 	await expect.poll(() => originalVideo.evaluate((element) => (element as HTMLVideoElement).currentTime)).toBeGreaterThan(beforeTime);
  251 | 	const pool = new Pool({ connectionString: browserDatabaseUrl(), max: 1 });
  252 | 	try {
  253 | 		const execution = (await pool.query("SELECT state,execution_generation FROM runner_broadcast_admissions WHERE session_id=$1", [world.sessionId])).rows;
  254 | 		expect(execution).toEqual([{ state: "active", execution_generation: world.generation }]);
  255 | 		const settings = (await pool.query("SELECT watermark_corner,pro_show_attribution,revision FROM runner_branding_profiles WHERE runner_id=$1", [world.runnerId])).rows;
  256 | 		expect(settings).toEqual([{ watermark_corner: "top_left", pro_show_attribution: false, revision: 1 }]);
  257 | 	} finally {
  258 | 		await pool.end();
  259 | 	}
  260 | });
  261 | 
  262 | When("its owner renews Pro before that deadline", async ({ mcpWorld }) => {
  263 | 	const world = presentationState(mcpWorld.input);
  264 | 	const { deadline } = mcpWorld.input!.runnerPresentationExpiry as { deadline: number };
  265 | 	expect(Date.now()).toBeLessThan(deadline);
  266 | 	const renewedDeadline = deadline + 60000;
  267 | 	const pool = new Pool({ connectionString: browserDatabaseUrl(), max: 1 });
  268 | 	try {
  269 | 		const renewed = await pool.query("UPDATE entitlement_grants SET ends_at=$2 WHERE user_id=$1 AND entitlement='pro_access' AND source='reverse_trial' RETURNING ends_at", [world.owner.fixture.creatorId, new Date(renewedDeadline)]);
  270 | 		expect(renewed.rowCount).toBe(1);
  271 | 	} finally {
  272 | 		await pool.end();
  273 | 	}
  274 | 	mcpWorld.input = { ...mcpWorld.input, runnerRenewedAppearanceDeadline: renewedDeadline };
  275 | });
  276 | 
  277 | Then("its original clip stays clean beyond the former deadline", async ({ page, mcpWorld }) => {
  278 | 	const world = presentationState(mcpWorld.input);
  279 | 	const { deadline, beforeTime } = mcpWorld.input!.runnerPresentationExpiry as { deadline: number; beforeTime: number };
  280 | 	await expect.poll(() => Date.now(), { timeout: Math.max(0, deadline - Date.now()) + 5000 }).toBeGreaterThan(deadline + 500);
  281 | 	expect(Date.now()).toBeLessThan(mcpWorld.input!.runnerRenewedAppearanceDeadline as number);
  282 | 	await expect(page.locator("[data-runner-attribution]")).toHaveCount(0);
  283 | 	await expect(page.locator("[data-runner-presentation-generation]")).toHaveAttribute("data-runner-presentation-generation", world.generation);
  284 | 	await expect(page.locator("[data-runner-presentation-generation]")).toHaveAttribute("data-runner-layout-status", "clean");
  285 | 	const video = page.locator(`video[data-expiry-continuity="${world.generation}"]`);
  286 | 	await expect(video).toHaveCount(1);
  287 | 	await expect.poll(() => video.evaluate((element) => (element as HTMLVideoElement).currentTime)).toBeGreaterThan(beforeTime);
  288 | });
  289 | 
  290 | Then("their standby background color matches draft preview and saved generated standby", async ({ page, mcpWorld }) => {
  291 | 	const color = page.getByLabel("Standby background color", { exact: true });
> 292 | 	await expect(color).toBeVisible();
      |                      ^ Error: expect(locator).toBeVisible() failed
  293 | 	await color.fill("#16324f");
  294 | 	const standby = page.frameLocator('iframe[title="Runner appearance preview"]').locator("[data-runner-standby]");
  295 | 	await expect(standby).toHaveCSS("background-color", "rgb(22, 50, 79)");
  296 | 	await page.getByRole("button", { name: "Save appearance", exact: true }).click();
  297 | 	await expect(page.getByRole("status").filter({ hasText: "Appearance saved" })).toBeVisible();
  298 | 	await page.reload();
  299 | 	await expect(color).toHaveValue("#16324f");
  300 | 	await expect(standby).toHaveCSS("background-color", "rgb(22, 50, 79)");
  301 | 	const world = presentationState(mcpWorld.input);
  302 | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  303 | 	expect(response.status()).toBe(200);
  304 | 	const { url } = await response.json();
  305 | 	await page.goto(`http://127.0.0.1:3107${url}`);
  306 | 	await expect(page.locator("[data-runner-standby]")).toHaveCSS("background-color", "rgb(22, 50, 79)");
  307 | });
  308 | 
```