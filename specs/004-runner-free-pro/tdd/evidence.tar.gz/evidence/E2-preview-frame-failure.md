# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: .features-gen/bdd/runner-branding.feature.spec.js >> Runner attribution placement >> A Free owner saves a preferred top-left attribution position
- Location: .features-gen/bdd/runner-branding.feature.spec.js:6:7

# Error details

```
Error: expect(locator).toBeVisible() failed

Locator: locator('iframe[title="Runner appearance preview"]').contentFrame().getByLabel('Livestream powered by Clipify.us', { exact: true })
Expected: visible
Timeout: 15000ms
Error: element(s) not found

Call log:
  - Expect "toBeVisible" locator('iframe[title="Runner appearance preview"]').contentFrame().getByLabel('Livestream powered by Clipify.us', { exact: true }) with timeout 15000ms
  - waiting for locator('iframe[title="Runner appearance preview"]').contentFrame().getByLabel('Livestream powered by Clipify.us', { exact: true })

```

```yaml
- button "Enable support chat"
- button "Report a problem":
  - img
  - text: Report a problem
- alert
- navigation:
  - link "Clipify":
    - /url: /dashboard
    - img
    - paragraph: Clipify
  - list:
    - listitem:
      - text: Account
      - group:
        - text: E2E Creator Account
        - button "E2E Creator Account Account context Account"
    - listitem:
      - button "Toggle Theme":
        - img
    - listitem:
      - button "Open profile menu":
        - text: E2
        - status "Online"
- main:
  - heading "Runner Settings" [level=1]
  - paragraph: Configure hardware streaming
  - button:
    - img
  - heading "Runner Settings" [level=1]
  - text: Streaming (LIVE)
  - button "Unlink runner" [disabled]:
    - img
  - separator
  - heading "Setup Your Runner" [level=2]
  - paragraph: This runner is linked to your account but is not connected yet. Download the runner for your operating system, run it, and approve the browser enrollment prompt. It will connect to this Clipify environment automatically.
  - button "Download for Windows":
    - img
    - text: Download for Windows
  - button "Download for Linux":
    - img
    - text: Download for Linux
  - button "Download for macOS":
    - img
    - text: Download for macOS
  - heading "Appearance" [level=2]
  - paragraph: Choose where Clipify attribution appears on generated content.
  - text: Attribution corner
  - button "Top left Attribution corner": Top left
  - button "Save appearance"
  - iframe
  - heading "Broadcast schedule" [level=2]:
    - img
    - text: Broadcast schedule
  - paragraph: Plan one-time or weekly broadcasts. Your Runner computer must stay on.
  - button "Add schedule" [disabled]:
    - img
    - text: Add schedule
  - paragraph: Pro includes scheduled broadcasts. Your saved schedules are retained, and Manual broadcasting remains available.
  - region "Broadcast calendar":
    - heading "Broadcast calendar" [level=3]
    - paragraph: Week view · Dates use UTC
    - text: Displayed date
    - textbox "Displayed date": 2026-10-17
    - text: Calendar timezone
    - combobox "Calendar timezone":
      - option "UTC" [selected]
    - button "Previous week": Previous
    - button "Today"
    - button "Next week": Next
    - text: Sun 11 Mon 12 Tue 13 Wed 14 Thu 15 Fri 16 Sat 17 1 AM 2 AM 3 AM 4 AM 5 AM 6 AM 7 AM 8 AM 9 AM 10 AM 11 AM 12 PM 1 PM 2 PM 3 PM 4 PM 5 PM 6 PM 7 PM 8 PM 9 PM 10 PM 11 PM
  - paragraph: No scheduled broadcasts yet.
  - heading "Destinations" [level=2]
  - paragraph: Save your streaming destinations and manage their protected keys.
  - button "Add destination":
    - img
    - text: Add destination
  - paragraph: No saved destinations yet.
```

# Test source

```ts
  1  | import { createBdd } from "playwright-bdd";
  2  | import type { Locator } from "@playwright/test";
  3  | import { test, expect } from "../support/mcp-support";
  4  | import { state } from "../support/runner-presentation";
  5  | 
  6  | const { When, Then } = createBdd(test);
  7  | 
  8  | When("its owner opens the Runner appearance settings", async ({ page, mcpWorld }) => {
  9  | 	const world = state(mcpWorld.input);
  10 | 	await page.context().addCookies([world.owner.cookie]);
  11 | 	await page.goto("http://127.0.0.1:3107/legal/cookies");
  12 | 	await expect(page.getByRole("button", { name: "Enable support chat", exact: true })).toBeVisible();
  13 | 	const preferences = page.getByRole("main").getByRole("button", { name: "Cookie preferences", exact: true });
  14 | 	await preferences.focus();
  15 | 	await preferences.press("Enter");
  16 | 	const privacy = page.getByRole("dialog", { name: "Privacy preferences", exact: true });
  17 | 	await expect(privacy).toBeVisible();
  18 | 	await Promise.all([page.waitForEvent("load"), privacy.getByRole("button", { name: "Reject optional", exact: true }).click()]);
  19 | 	await page.goto(`http://127.0.0.1:3107/dashboard/runners/${world.runnerId}`);
  20 | 	await expect(page.getByRole("heading", { name: "Destinations", exact: true })).toBeVisible();
  21 | });
  22 | 
  23 | async function expectTopLeftAttribution(badge: Locator) {
> 24 | 	await expect(badge).toBeVisible();
     |                      ^ Error: expect(locator).toBeVisible() failed
  25 | 	await expect(badge.getByText("Livestream powered", { exact: true })).toBeVisible();
  26 | 	await expect(badge.getByText("by Clipify.us", { exact: true })).toBeVisible();
  27 | 	const geometry = await badge.evaluate((element) => {
  28 | 		const box = element.getBoundingClientRect();
  29 | 		return { left: box.left, top: box.top, width: box.width, height: box.height, viewportWidth: innerWidth, viewportHeight: innerHeight };
  30 | 	});
  31 | 	const scale = Math.min(geometry.viewportWidth / 1920, geometry.viewportHeight / 1080);
  32 | 	expect(geometry.left).toBeCloseTo(24 * scale, 0);
  33 | 	expect(geometry.top).toBeCloseTo(24 * scale, 0);
  34 | 	expect(geometry.width).toBeGreaterThan(0);
  35 | 	expect(geometry.height).toBeGreaterThan(0);
  36 | 	const fontSize = await badge.getByText("Livestream powered", { exact: true }).evaluate((element) => Number.parseFloat(getComputedStyle(element).fontSize));
  37 | 	expect(fontSize).toBeCloseTo(56 * scale, 0);
  38 | }
  39 | 
  40 | Then("choosing top-left persists and the preview and generated presentation use that corner", async ({ page, mcpWorld }) => {
  41 | 	const corner = page.getByRole("button", { name: /Attribution corner$/ });
  42 | 	await expect(corner, "The owner must have an attribution corner selector").toBeVisible();
  43 | 	await corner.click();
  44 | 	await page.getByRole("option", { name: "Top left", exact: true }).click();
  45 | 	await page.getByRole("button", { name: "Save appearance", exact: true }).click();
  46 | 	await expect(page.getByRole("status").filter({ hasText: "Appearance saved" })).toBeVisible();
  47 | 	await page.reload();
  48 | 	await expect(corner).toContainText("Top left");
  49 | 	await expectTopLeftAttribution(page.frameLocator('iframe[title="Runner appearance preview"]').getByLabel("Livestream powered by Clipify.us", { exact: true }));
  50 | 	const world = state(mcpWorld.input);
  51 | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  52 | 	expect(response.status()).toBe(200);
  53 | 	const { url } = await response.json();
  54 | 	await page.goto(`http://127.0.0.1:3107${url}`);
  55 | 	await expectTopLeftAttribution(page.getByLabel("Livestream powered by Clipify.us", { exact: true }));
  56 | });
  57 | 
```