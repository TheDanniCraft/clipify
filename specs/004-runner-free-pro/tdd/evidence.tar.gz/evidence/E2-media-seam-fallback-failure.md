# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: .features-gen/bdd/runner-presentation.feature.spec.js >> Runner-generated presentation >> Live forwarding bypasses attribution across generated fallback and return
- Location: .features-gen/bdd/runner-presentation.feature.spec.js:24:7

# Error details

```
Error: Native fallback presentation failed (1): (node:3295292) Warning: The 'NO_COLOR' env is ignored due to the 'FORCE_COLOR' env being set.
(Use `node --trace-warnings ...` to show where the warning was created)
[OBS Forwarder] 🔴 Stopped unexpectedly. Last log: Exiting normally, received signal 2.
Fallback did not play a real selected clip

```

# Test source

```ts
  16  | 	await preparePresentationFixture(request, mcpWorld, true);
  17  | 	const world = state(mcpWorld.input),
  18  | 		pool = new Pool({ connectionString: browserDatabaseUrl(), max: 1 });
  19  | 	try {
  20  | 		await pool.query("UPDATE stream_sessions SET mode='failsafe' WHERE id=$1", [world.sessionId]);
  21  | 		await pool.query("UPDATE runner_broadcast_admissions SET benefits_at_start=benefits_at_start || $2::jsonb WHERE session_id=$1", [world.sessionId, JSON.stringify({ ingestModeAtStart: "failsafe" })]);
  22  | 	} finally {
  23  | 		await pool.end();
  24  | 	}
  25  | });
  26  | 
  27  | When("the Runner requests its generated presentation", async ({ page, mcpWorld }) => {
  28  | 	const world = state(mcpWorld.input);
  29  | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  30  | 	world.status = response.status();
  31  | 	if (world.status === 200) world.body = await response.json();
  32  | });
  33  | 
  34  | Then("its generated standby visibly credits Clipify", async ({ page, mcpWorld }) => {
  35  | 	const world = state(mcpWorld.input);
  36  | 	expect(world.status, "The assigned active Runner must receive its authorized generated presentation").toBe(200);
  37  | 	expect(world.body?.url).toBe(`/runner/presentation/${world.sessionId}`);
  38  | 	await page.goto(`http://127.0.0.1:3107${world.body!.url}`);
  39  | 	await expect(page.locator("[data-runner-presentation-generation]")).toHaveAttribute("data-runner-presentation-generation", world.generation);
  40  | 	await expect(page.getByText("Livestream powered", { exact: true })).toBeVisible();
  41  | 	await expect(page.getByText("by Clipify.us", { exact: true })).toBeVisible();
  42  | 	await page.screenshot({ path: "specs/004-runner-free-pro/tdd/evidence/E1-free-standby.png" });
  43  | 	await page.goto(`http://127.0.0.1:3107${world.body!.url}?watermark=false&runnerPro=true&attributionRequired=false`);
  44  | 	await expect(page.getByText("Livestream powered", { exact: true })).toBeVisible();
  45  | 	await expect(page.getByText("by Clipify.us", { exact: true })).toBeVisible();
  46  | });
  47  | 
  48  | When("the owner opens the ordinary overlay source", async ({ page, mcpWorld }) => {
  49  | 	const world = state(mcpWorld.input);
  50  | 	const response = await page.goto(`http://127.0.0.1:3107/overlay/${world.owner.fixture.overlayId}?secret=${encodeURIComponent(world.sourceSecret!)}&standby=true`);
  51  | 	world.status = response?.status();
  52  | });
  53  | 
  54  | Then("the ordinary overlay contains its player without Runner attribution", async ({ page, mcpWorld }) => {
  55  | 	expect(state(mcpWorld.input).status).toBe(200);
  56  | 	await expect.poll(() => page.evaluate(() => typeof (window as PlaybackWindow).startRunnerPlayback)).toBe("function");
  57  | 	await expect(page.locator("[data-runner-attribution]")).toHaveCount(0);
  58  | 	await expect(page.locator("[data-runner-presentation-generation]")).toHaveCount(0);
  59  | 	await expect(page.getByText("Livestream powered", { exact: true })).toHaveCount(0);
  60  | });
  61  | 
  62  | When("the Runner starts generated clip playback", async ({ page, mcpWorld }) => {
  63  | 	const world = state(mcpWorld.input);
  64  | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  65  | 	world.status = response.status();
  66  | 	if (world.status !== 200) return;
  67  | 	world.body = await response.json();
  68  | 	await page.setViewportSize({ width: 1920, height: 1080 });
  69  | 	await page.goto(`http://127.0.0.1:3107${world.body!.url}`);
  70  | 	await page.waitForFunction(() => typeof (window as PlaybackWindow).startRunnerPlayback === "function");
  71  | 	await page.evaluate(() => (window as PlaybackWindow).startRunnerPlayback?.());
  72  | });
  73  | 
  74  | Then("its playing clip visibly retains Clipify attribution", async ({ page, mcpWorld }) => {
  75  | 	expect(state(mcpWorld.input).status).toBe(200);
  76  | 	await expect
  77  | 		.poll(() =>
  78  | 			page
  79  | 				.locator("video")
  80  | 				.first()
  81  | 				.evaluate((video) => (video as HTMLVideoElement).currentTime),
  82  | 		)
  83  | 		.toBeGreaterThan(0.2);
  84  | 	await expect(page.getByText("Livestream powered", { exact: true })).toBeVisible();
  85  | 	await expect(page.getByText("by Clipify.us", { exact: true })).toBeVisible();
  86  | 	await page.screenshot({ path: "specs/004-runner-free-pro/tdd/evidence/E1-free-playback.png" });
  87  | });
  88  | 
  89  | When("its live input disconnects and then returns through the native Runner", async ({ mcpWorld }) => {
  90  | 	test.setTimeout(120000);
  91  | 	const world = state(mcpWorld.input);
  92  | 	world.nativeResult = await new Promise<NonNullable<PresentationWorld["nativeResult"]>>((resolve, reject) => {
  93  | 		const child = spawn(process.execPath, [join(process.cwd(), "packages/runner/test/support/fallback-presentation-probe.mjs")], { stdio: ["pipe", "pipe", "pipe"], env: { ...process.env, NODE_OPTIONS: "" } });
  94  | 		let output = "",
  95  | 			errors = "",
  96  | 			hardStop: ReturnType<typeof setTimeout> | undefined;
  97  | 		const timer = setTimeout(() => {
  98  | 			child.kill("SIGTERM");
  99  | 			hardStop = setTimeout(() => child.kill("SIGKILL"), 10000);
  100 | 		}, 90000);
  101 | 		child.stdout.on("data", (data) => {
  102 | 			output = (output + String(data)).slice(-65536);
  103 | 		});
  104 | 		child.stderr.on("data", (data) => {
  105 | 			errors = (errors + String(data)).slice(-6000);
  106 | 		});
  107 | 		child.on("error", (error) => {
  108 | 			clearTimeout(timer);
  109 | 			if (hardStop) clearTimeout(hardStop);
  110 | 			reject(error);
  111 | 		});
  112 | 		child.on("close", (code) => {
  113 | 			clearTimeout(timer);
  114 | 			if (hardStop) clearTimeout(hardStop);
  115 | 			if (code !== 0) {
> 116 | 				reject(new Error(`Native fallback presentation failed (${code}): ${errors}`));
      |            ^ Error: Native fallback presentation failed (1): (node:3295292) Warning: The 'NO_COLOR' env is ignored due to the 'FORCE_COLOR' env being set.
  117 | 				return;
  118 | 			}
  119 | 			const line = output
  120 | 				.trim()
  121 | 				.split("\n")
  122 | 				.findLast((value) => value.startsWith("{"));
  123 | 			try {
  124 | 				resolve(JSON.parse(line ?? ""));
  125 | 			} catch {
  126 | 				reject(new Error("Native fallback presentation returned no result"));
  127 | 			}
  128 | 		});
  129 | 		child.stdin.end(JSON.stringify({ overlayId: world.owner.fixture.overlayId, overlaySecret: world.sourceSecret, sessionId: world.sessionId, executionGeneration: world.generation, apiBase: "http://127.0.0.1:3107", runnerToken: world.token }));
  130 | 	});
  131 | });
  132 | 
  133 | Then("only the generated fallback is branded in the encoded output", async ({ mcpWorld }) => {
  134 | 	const result = state(mcpWorld.input).nativeResult!;
  135 | 	expect(result.authenticatedPresentation).toBe(true);
  136 | 	expect(result.realPlayback).toBe(true);
  137 | 	expect(result.live.redPixels).toBeGreaterThan(50000);
  138 | 	expect(result.live.whitePixels).toBeLessThan(5);
  139 | 	expect(result.fallback.bluePixels).toBeGreaterThan(30000);
  140 | 	expect(result.fallback.attributionVisible).toBe(true);
  141 | 	expect(result.fallback.attributionWhitePixels).toBeGreaterThan(40);
  142 | 	expect(result.returned.redPixels).toBeGreaterThan(50000);
  143 | 	expect(result.returned.whitePixels).toBeLessThan(5);
  144 | 	await test.info().attach("encoded-output-observations", { body: JSON.stringify(result), contentType: "application/json" });
  145 | 	await writeFile("specs/004-runner-free-pro/tdd/evidence/E1-fallback-encoded-output-observations.json", JSON.stringify(result, null, 2) + "\n");
  146 | });
  147 | 
  148 | AfterScenario({ tags: "@runner-presentation-browser" }, async ({ request, mcpWorld }) => {
  149 | 	const world = state(mcpWorld.input);
  150 | 	if (!world) return;
  151 | 	const { fixture } = world.owner;
  152 | 	if (world.clipId) {
  153 | 		const pool = new Pool({ connectionString: browserDatabaseUrl(), max: 1 });
  154 | 		try {
  155 | 			await pool.query(`DELETE FROM "twitchCache" WHERE type='clip' AND key=$1`, [`clip:${fixture.creatorId}:${world.clipId}`]);
  156 | 		} finally {
  157 | 			await pool.end();
  158 | 		}
  159 | 	}
  160 | 	const response = await request.delete("http://127.0.0.1:3107/api/test/auth-fixture", { headers: fixtureHeaders, data: { authUserId: fixture.authUserId, creatorId: fixture.creatorId, organizationIds: [fixture.creatorOrganizationId, fixture.agencyOrganizationId] } });
  161 | 	expect(response.status()).toBe(204);
  162 | });
  163 | 
```