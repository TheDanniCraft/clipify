# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: .features-gen/bdd/mcp-support/playlist_add_expiry.feature.spec.js >> Reject late AI authority expiry when adding validated clips >> Validated clip addition rechecks authority after waiting for the playlist >> Example #3
- Location: .features-gen/bdd/mcp-support/playlist_add_expiry.feature.spec.js:20:9

# Error details

```
Error: expect(received).toBe(expected) // Object.is equality

Expected: true
Received: false
```

# Test source

```ts
  1  | import { createBdd } from "playwright-bdd";
  2  | import { expect } from "@playwright/test";
  3  | import { runMcpProbe } from "../../support/mcp/probe";
  4  | const { Given, When, Then } = createBdd();
  5  | let authority: string;
  6  | let result: ReturnType<typeof runMcpProbe>;
  7  | Given("AI clip addition uses creator credentials and waits with {string} authority", async ({}, expiry: string) => {
  8  | 	authority = expiry;
  9  | });
  10 | When("the playlist becomes available after that addition authority boundary", async () => {
  11 | 	result = runMcpProbe("playlist-add-expiry-probe", [authority]);
  12 | });
  13 | Then("expired authority preserves items revision and audit while active authority appends the validated clip", async () => {
> 14 | 	expect(result.waited).toBe(true);
     |                        ^ Error: expect(received).toBe(expected) // Object.is equality
  15 | 	expect(result.providerCalls).toBe(1);
  16 | 	expect(result.credentialUsed).toBe(true);
  17 | 	expect(result.success).toBe(authority === "active");
  18 | 	expect(result.error).toBe(authority === "active" ? null : "AUTHENTICATION_REQUIRED");
  19 | 	expect(result.current).toEqual({ name: "Before", configuration_revision: authority === "active" ? 2 : 1 });
  20 | 	expect(result.audits).toBe(authority === "active" ? 1 : 0);
  21 | 	const ids = authority === "active" ? ["clip-a", "clip-b", "NewClip"] : ["clip-a", "clip-b"];
  22 | 	expect(result.items).toEqual(ids.map((clip_id, position) => ({ clip_id, position })));
  23 | });
  24 | 
```