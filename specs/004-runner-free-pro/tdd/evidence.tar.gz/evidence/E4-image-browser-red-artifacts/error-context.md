# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: .features-gen/bdd/runner-standby.feature.spec.js >> Runner standby customization >> A Pro owner previews and saves a standby background image
- Location: .features-gen/bdd/runner-standby.feature.spec.js:12:7

# Error details

```
Test timeout of 60000ms exceeded.
```

```
Error: locator.setInputFiles: Test timeout of 60000ms exceeded.
Call log:
  - waiting for getByLabel('Standby background image', { exact: true })

```

# Page snapshot

```yaml
- generic [active] [ref=f2e1]:
  - button "Enable support chat" [ref=f2e2] [cursor=pointer]
  - button "Report a problem" [ref=f2e3] [cursor=pointer]
  - alert [ref=f2e8]
  - navigation [ref=f2e9]:
    - generic [ref=f2e10]:
      - link [ref=f2e11] [cursor=pointer]:
        - /url: /dashboard
        - paragraph [ref=f2e16]: Clipify
      - list [ref=f2e17]:
        - listitem [ref=f2e18]:
          - generic [ref=f2e19]:
            - generic [ref=f2e20]: Account
            - group [ref=f2e21] [cursor=pointer]:
              - generic [ref=f2e25]: E2E Creator Account
              - button "E2E Creator Account Account context Account"
            - combobox [ref=f2e30]
        - listitem [ref=f2e31]:
          - button "Toggle Theme" [ref=f2e32] [cursor=pointer]
        - listitem [ref=f2e33]:
          - button "Open profile menu" [ref=f2e34] [cursor=pointer]:
            - generic [ref=f2e35]:
              - generic [ref=f2e36]: E2
              - status "Online" [ref=f2e38]
  - main [ref=f2e40]:
    - generic [ref=f2e41]:
      - generic [ref=f2e43]:
        - heading "Runner Settings" [level=1] [ref=f2e44]
        - paragraph [ref=f2e45]: Configure hardware streaming
      - generic [ref=f2e46]:
        - generic [ref=f2e47]:
          - generic [ref=f2e48]:
            - generic [ref=f2e49]:
              - button [ref=f2e50] [cursor=pointer]
              - heading "Runner Settings" [level=1] [ref=f2e51]
            - generic [ref=f2e53]:
              - generic [ref=f2e54]: Streaming (LIVE)
              - button "Unlink runner" [disabled]
          - separator [ref=f2e56]
          - generic [ref=f2e58]:
            - heading "Setup Your Runner" [level=2] [ref=f2e59]
            - paragraph [ref=f2e60]: This runner is linked to your account but is not connected yet. Download the runner for your operating system, run it, and approve the browser enrollment prompt. It will connect to this Clipify environment automatically.
            - generic [ref=f2e61]:
              - button "Download for Windows" [ref=f2e62] [cursor=pointer]
              - button "Download for Linux" [ref=f2e63] [cursor=pointer]
              - button "Download for macOS" [ref=f2e64] [cursor=pointer]
        - generic [ref=f2e65]:
          - generic [ref=f2e66]:
            - heading "Appearance" [level=2] [ref=f2e67]
            - paragraph [ref=f2e68]: Choose where Clipify attribution appears on generated content.
          - generic [ref=f2e69]:
            - generic [ref=f2e70]:
              - text: Standby background color
              - textbox "Standby background color" [ref=f2e71] [cursor=pointer]: "#000000"
            - generic [ref=f2e73] [cursor=pointer]:
              - switch "Show Clipify attribution" [ref=f2e75]
              - generic [ref=f2e78]: Show Clipify attribution
            - generic [ref=f2e79]:
              - generic [ref=f2e80]: Attribution corner
              - button "Bottom right Attribution corner" [ref=f2e81] [cursor=pointer]:
                - generic [ref=f2e82]: Bottom right
              - combobox [ref=f2e87]
            - button "Save appearance" [ref=f2e88] [cursor=pointer]
            - iframe [ref=f2e90]:
              - alert [ref=f3e4]
        - generic [ref=f2e91]:
          - generic [ref=f2e92]:
            - generic [ref=f2e93]:
              - heading "Broadcast schedule" [level=2] [ref=f2e94]
              - paragraph [ref=f2e98]: Plan one-time or weekly broadcasts. Your Runner computer must stay on.
            - button "Add schedule" [ref=f2e99] [cursor=pointer]
          - generic [ref=f2e100]:
            - region "Broadcast calendar" [ref=f2e101]:
              - generic [ref=f2e102]:
                - generic [ref=f2e103]:
                  - heading "Broadcast calendar" [level=3] [ref=f2e104]
                  - paragraph [ref=f2e105]: Week view · Dates use UTC
                - generic [ref=f2e106]:
                  - text: Displayed date
                  - textbox "Displayed date" [ref=f2e107]: 2026-10-17
                - generic [ref=f2e108]:
                  - text: Calendar timezone
                  - combobox "Calendar timezone" [ref=f2e109]:
                    - option "UTC" [selected]
                - generic [ref=f2e110]:
                  - button "Previous week" [ref=f2e111] [cursor=pointer]: Previous
                  - button "Today" [ref=f2e112] [cursor=pointer]
                  - button "Next week" [ref=f2e113] [cursor=pointer]: Next
              - generic [ref=f2e115]:
                - generic [ref=f2e116]:
                  - generic [ref=f2e117]:
                    - generic [ref=f2e118]: Sun
                    - generic [ref=f2e119]: "11"
                  - generic [ref=f2e120]:
                    - generic [ref=f2e121]: Mon
                    - generic [ref=f2e122]: "12"
                  - generic [ref=f2e123]:
                    - generic [ref=f2e124]: Tue
                    - generic [ref=f2e125]: "13"
                  - generic [ref=f2e126]:
                    - generic [ref=f2e127]: Wed
                    - generic [ref=f2e128]: "14"
                  - generic [ref=f2e129]:
                    - generic [ref=f2e130]: Thu
                    - generic [ref=f2e131]: "15"
                  - generic [ref=f2e132]:
                    - generic [ref=f2e133]: Fri
                    - generic [ref=f2e134]: "16"
                  - generic [ref=f2e135]:
                    - generic [ref=f2e136]: Sat
                    - generic [ref=f2e137]: "17"
                - generic [ref=f2e139]:
                  - generic [ref=f2e140]:
                    - generic [ref=f2e142]: 1 AM
                    - generic [ref=f2e144]: 2 AM
                    - generic [ref=f2e146]: 3 AM
                    - generic [ref=f2e148]: 4 AM
                    - generic [ref=f2e150]: 5 AM
                    - generic [ref=f2e152]: 6 AM
                    - generic [ref=f2e154]: 7 AM
                    - generic [ref=f2e156]: 8 AM
                    - generic [ref=f2e158]: 9 AM
                    - generic [ref=f2e160]: 10 AM
                    - generic [ref=f2e162]: 11 AM
                    - generic [ref=f2e164]: 12 PM
                    - generic [ref=f2e166]: 1 PM
                    - generic [ref=f2e168]: 2 PM
                    - generic [ref=f2e170]: 3 PM
                    - generic [ref=f2e172]: 4 PM
                    - generic [ref=f2e174]: 5 PM
                    - generic [ref=f2e176]: 6 PM
                    - generic [ref=f2e178]: 7 PM
                    - generic [ref=f2e180]: 8 PM
                    - generic [ref=f2e182]: 9 PM
                    - generic [ref=f2e184]: 10 PM
                    - generic [ref=f2e186]: 11 PM
                  - generic [ref=f2e188]:
                    - generic [ref=f2e189] [cursor=pointer]
                    - generic [ref=f2e190] [cursor=pointer]
                    - generic [ref=f2e191] [cursor=pointer]
                    - generic [ref=f2e192] [cursor=pointer]
                    - generic [ref=f2e193] [cursor=pointer]
                    - generic [ref=f2e194] [cursor=pointer]
                    - generic [ref=f2e195] [cursor=pointer]
                    - generic [ref=f2e196] [cursor=pointer]
                    - generic [ref=f2e197] [cursor=pointer]
                    - generic [ref=f2e198] [cursor=pointer]
                    - generic [ref=f2e199] [cursor=pointer]
                    - generic [ref=f2e200] [cursor=pointer]
                    - generic [ref=f2e201] [cursor=pointer]
                    - generic [ref=f2e202] [cursor=pointer]
                    - generic [ref=f2e203] [cursor=pointer]
                    - generic [ref=f2e204] [cursor=pointer]
                    - generic [ref=f2e205] [cursor=pointer]
                    - generic [ref=f2e206] [cursor=pointer]
                    - generic [ref=f2e207] [cursor=pointer]
                    - generic [ref=f2e208] [cursor=pointer]
                    - generic [ref=f2e209] [cursor=pointer]
                    - generic [ref=f2e210] [cursor=pointer]
                    - generic [ref=f2e211] [cursor=pointer]
                    - generic [ref=f2e212] [cursor=pointer]
                    - generic [ref=f2e213] [cursor=pointer]
                    - generic [ref=f2e214] [cursor=pointer]
                    - generic [ref=f2e215] [cursor=pointer]
                    - generic [ref=f2e216] [cursor=pointer]
                    - generic [ref=f2e217] [cursor=pointer]
                    - generic [ref=f2e218] [cursor=pointer]
                    - generic [ref=f2e219] [cursor=pointer]
                    - generic [ref=f2e220] [cursor=pointer]
                    - generic [ref=f2e221] [cursor=pointer]
                    - generic [ref=f2e222] [cursor=pointer]
                    - generic [ref=f2e223] [cursor=pointer]
                    - generic [ref=f2e224] [cursor=pointer]
                    - generic [ref=f2e225] [cursor=pointer]
                    - generic [ref=f2e226] [cursor=pointer]
                    - generic [ref=f2e227] [cursor=pointer]
                    - generic [ref=f2e228] [cursor=pointer]
                    - generic [ref=f2e229] [cursor=pointer]
                    - generic [ref=f2e230] [cursor=pointer]
                    - generic [ref=f2e231] [cursor=pointer]
                    - generic [ref=f2e232] [cursor=pointer]
                    - generic [ref=f2e233] [cursor=pointer]
                    - generic [ref=f2e234] [cursor=pointer]
                    - generic [ref=f2e235] [cursor=pointer]
                    - generic [ref=f2e236] [cursor=pointer]
                  - generic [ref=f2e237]:
                    - generic [ref=f2e238] [cursor=pointer]
                    - generic [ref=f2e239] [cursor=pointer]
                    - generic [ref=f2e240] [cursor=pointer]
                    - generic [ref=f2e241] [cursor=pointer]
                    - generic [ref=f2e242] [cursor=pointer]
                    - generic [ref=f2e243] [cursor=pointer]
                    - generic [ref=f2e244] [cursor=pointer]
                    - generic [ref=f2e245] [cursor=pointer]
                    - generic [ref=f2e246] [cursor=pointer]
                    - generic [ref=f2e247] [cursor=pointer]
                    - generic [ref=f2e248] [cursor=pointer]
                    - generic [ref=f2e249] [cursor=pointer]
                    - generic [ref=f2e250] [cursor=pointer]
                    - generic [ref=f2e251] [cursor=pointer]
                    - generic [ref=f2e252] [cursor=pointer]
                    - generic [ref=f2e253] [cursor=pointer]
                    - generic [ref=f2e254] [cursor=pointer]
                    - generic [ref=f2e255] [cursor=pointer]
                    - generic [ref=f2e256] [cursor=pointer]
                    - generic [ref=f2e257] [cursor=pointer]
                    - generic [ref=f2e258] [cursor=pointer]
                    - generic [ref=f2e259] [cursor=pointer]
                    - generic [ref=f2e260] [cursor=pointer]
                    - generic [ref=f2e261] [cursor=pointer]
                    - generic [ref=f2e262] [cursor=pointer]
                    - generic [ref=f2e263] [cursor=pointer]
                    - generic [ref=f2e264] [cursor=pointer]
                    - generic [ref=f2e265] [cursor=pointer]
                    - generic [ref=f2e266] [cursor=pointer]
                    - generic [ref=f2e267] [cursor=pointer]
                    - generic [ref=f2e268] [cursor=pointer]
                    - generic [ref=f2e269] [cursor=pointer]
                    - generic [ref=f2e270] [cursor=pointer]
                    - generic [ref=f2e271] [cursor=pointer]
                    - generic [ref=f2e272] [cursor=pointer]
                    - generic [ref=f2e273] [cursor=pointer]
                    - generic [ref=f2e274] [cursor=pointer]
                    - generic [ref=f2e275] [cursor=pointer]
                    - generic [ref=f2e276] [cursor=pointer]
                    - generic [ref=f2e277] [cursor=pointer]
                    - generic [ref=f2e278] [cursor=pointer]
                    - generic [ref=f2e279] [cursor=pointer]
                    - generic [ref=f2e280] [cursor=pointer]
                    - generic [ref=f2e281] [cursor=pointer]
                    - generic [ref=f2e282] [cursor=pointer]
                    - generic [ref=f2e283] [cursor=pointer]
                    - generic [ref=f2e284] [cursor=pointer]
                    - generic [ref=f2e285] [cursor=pointer]
                  - generic [ref=f2e286]:
                    - generic [ref=f2e287] [cursor=pointer]
                    - generic [ref=f2e288] [cursor=pointer]
                    - generic [ref=f2e289] [cursor=pointer]
                    - generic [ref=f2e290] [cursor=pointer]
                    - generic [ref=f2e291] [cursor=pointer]
                    - generic [ref=f2e292] [cursor=pointer]
                    - generic [ref=f2e293] [cursor=pointer]
                    - generic [ref=f2e294] [cursor=pointer]
                    - generic [ref=f2e295] [cursor=pointer]
                    - generic [ref=f2e296] [cursor=pointer]
                    - generic [ref=f2e297] [cursor=pointer]
                    - generic [ref=f2e298] [cursor=pointer]
                    - generic [ref=f2e299] [cursor=pointer]
                    - generic [ref=f2e300] [cursor=pointer]
                    - generic [ref=f2e301] [cursor=pointer]
                    - generic [ref=f2e302] [cursor=pointer]
                    - generic [ref=f2e303] [cursor=pointer]
                    - generic [ref=f2e304] [cursor=pointer]
                    - generic [ref=f2e305] [cursor=pointer]
                    - generic [ref=f2e306] [cursor=pointer]
                    - generic [ref=f2e307] [cursor=pointer]
                    - generic [ref=f2e308] [cursor=pointer]
                    - generic [ref=f2e309] [cursor=pointer]
                    - generic [ref=f2e310] [cursor=pointer]
                    - generic [ref=f2e311] [cursor=pointer]
                    - generic [ref=f2e312] [cursor=pointer]
                    - generic [ref=f2e313] [cursor=pointer]
                    - generic [ref=f2e314] [cursor=pointer]
                    - generic [ref=f2e315] [cursor=pointer]
                    - generic [ref=f2e316] [cursor=pointer]
                    - generic [ref=f2e317] [cursor=pointer]
                    - generic [ref=f2e318] [cursor=pointer]
                    - generic [ref=f2e319] [cursor=pointer]
                    - generic [ref=f2e320] [cursor=pointer]
                    - generic [ref=f2e321] [cursor=pointer]
                    - generic [ref=f2e322] [cursor=pointer]
                    - generic [ref=f2e323] [cursor=pointer]
                    - generic [ref=f2e324] [cursor=pointer]
                    - generic [ref=f2e325] [cursor=pointer]
                    - generic [ref=f2e326] [cursor=pointer]
                    - generic [ref=f2e327] [cursor=pointer]
                    - generic [ref=f2e328] [cursor=pointer]
                    - generic [ref=f2e329] [cursor=pointer]
                    - generic [ref=f2e330] [cursor=pointer]
                    - generic [ref=f2e331] [cursor=pointer]
                    - generic [ref=f2e332] [cursor=pointer]
                    - generic [ref=f2e333] [cursor=pointer]
                    - generic [ref=f2e334] [cursor=pointer]
                  - generic [ref=f2e335]:
                    - generic [ref=f2e336] [cursor=pointer]
                    - generic [ref=f2e337] [cursor=pointer]
                    - generic [ref=f2e338] [cursor=pointer]
                    - generic [ref=f2e339] [cursor=pointer]
                    - generic [ref=f2e340] [cursor=pointer]
                    - generic [ref=f2e341] [cursor=pointer]
                    - generic [ref=f2e342] [cursor=pointer]
                    - generic [ref=f2e343] [cursor=pointer]
                    - generic [ref=f2e344] [cursor=pointer]
                    - generic [ref=f2e345] [cursor=pointer]
                    - generic [ref=f2e346] [cursor=pointer]
                    - generic [ref=f2e347] [cursor=pointer]
                    - generic [ref=f2e348] [cursor=pointer]
                    - generic [ref=f2e349] [cursor=pointer]
                    - generic [ref=f2e350] [cursor=pointer]
                    - generic [ref=f2e351] [cursor=pointer]
                    - generic [ref=f2e352] [cursor=pointer]
                    - generic [ref=f2e353] [cursor=pointer]
                    - generic [ref=f2e354] [cursor=pointer]
                    - generic [ref=f2e355] [cursor=pointer]
                    - generic [ref=f2e356] [cursor=pointer]
                    - generic [ref=f2e357] [cursor=pointer]
                    - generic [ref=f2e358] [cursor=pointer]
                    - generic [ref=f2e359] [cursor=pointer]
                    - generic [ref=f2e360] [cursor=pointer]
                    - generic [ref=f2e361] [cursor=pointer]
                    - generic [ref=f2e362] [cursor=pointer]
                    - generic [ref=f2e363] [cursor=pointer]
                    - generic [ref=f2e364] [cursor=pointer]
                    - generic [ref=f2e365] [cursor=pointer]
                    - generic [ref=f2e366] [cursor=pointer]
                    - generic [ref=f2e367] [cursor=pointer]
                    - generic [ref=f2e368] [cursor=pointer]
                    - generic [ref=f2e369] [cursor=pointer]
                    - generic [ref=f2e370] [cursor=pointer]
                    - generic [ref=f2e371] [cursor=pointer]
                    - generic [ref=f2e372] [cursor=pointer]
                    - generic [ref=f2e373] [cursor=pointer]
                    - generic [ref=f2e374] [cursor=pointer]
                    - generic [ref=f2e375] [cursor=pointer]
                    - generic [ref=f2e376] [cursor=pointer]
                    - generic [ref=f2e377] [cursor=pointer]
                    - generic [ref=f2e378] [cursor=pointer]
                    - generic [ref=f2e379] [cursor=pointer]
                    - generic [ref=f2e380] [cursor=pointer]
                    - generic [ref=f2e381] [cursor=pointer]
                    - generic [ref=f2e382] [cursor=pointer]
                    - generic [ref=f2e383] [cursor=pointer]
                  - generic [ref=f2e384]:
                    - generic [ref=f2e385] [cursor=pointer]
                    - generic [ref=f2e386] [cursor=pointer]
                    - generic [ref=f2e387] [cursor=pointer]
                    - generic [ref=f2e388] [cursor=pointer]
                    - generic [ref=f2e389] [cursor=pointer]
                    - generic [ref=f2e390] [cursor=pointer]
                    - generic [ref=f2e391] [cursor=pointer]
                    - generic [ref=f2e392] [cursor=pointer]
                    - generic [ref=f2e393] [cursor=pointer]
                    - generic [ref=f2e394] [cursor=pointer]
                    - generic [ref=f2e395] [cursor=pointer]
                    - generic [ref=f2e396] [cursor=pointer]
                    - generic [ref=f2e397] [cursor=pointer]
                    - generic [ref=f2e398] [cursor=pointer]
                    - generic [ref=f2e399] [cursor=pointer]
                    - generic [ref=f2e400] [cursor=pointer]
                    - generic [ref=f2e401] [cursor=pointer]
                    - generic [ref=f2e402] [cursor=pointer]
                    - generic [ref=f2e403] [cursor=pointer]
                    - generic [ref=f2e404] [cursor=pointer]
                    - generic [ref=f2e405] [cursor=pointer]
                    - generic [ref=f2e406] [cursor=pointer]
                    - generic [ref=f2e407] [cursor=pointer]
                    - generic [ref=f2e408] [cursor=pointer]
                    - generic [ref=f2e409] [cursor=pointer]
                    - generic [ref=f2e410] [cursor=pointer]
                    - generic [ref=f2e411] [cursor=pointer]
                    - generic [ref=f2e412] [cursor=pointer]
                    - generic [ref=f2e413] [cursor=pointer]
                    - generic [ref=f2e414] [cursor=pointer]
                    - generic [ref=f2e415] [cursor=pointer]
                    - generic [ref=f2e416] [cursor=pointer]
                    - generic [ref=f2e417] [cursor=pointer]
                    - generic [ref=f2e418] [cursor=pointer]
                    - generic [ref=f2e419] [cursor=pointer]
                    - generic [ref=f2e420] [cursor=pointer]
                    - generic [ref=f2e421] [cursor=pointer]
                    - generic [ref=f2e422] [cursor=pointer]
                    - generic [ref=f2e423] [cursor=pointer]
                    - generic [ref=f2e424] [cursor=pointer]
                    - generic [ref=f2e425] [cursor=pointer]
                    - generic [ref=f2e426] [cursor=pointer]
                    - generic [ref=f2e427] [cursor=pointer]
                    - generic [ref=f2e428] [cursor=pointer]
                    - generic [ref=f2e429] [cursor=pointer]
                    - generic [ref=f2e430] [cursor=pointer]
                    - generic [ref=f2e431] [cursor=pointer]
                    - generic [ref=f2e432] [cursor=pointer]
                  - generic [ref=f2e433]:
                    - generic [ref=f2e434] [cursor=pointer]
                    - generic [ref=f2e435] [cursor=pointer]
                    - generic [ref=f2e436] [cursor=pointer]
                    - generic [ref=f2e437] [cursor=pointer]
                    - generic [ref=f2e438] [cursor=pointer]
                    - generic [ref=f2e439] [cursor=pointer]
                    - generic [ref=f2e440] [cursor=pointer]
                    - generic [ref=f2e441] [cursor=pointer]
                    - generic [ref=f2e442] [cursor=pointer]
                    - generic [ref=f2e443] [cursor=pointer]
                    - generic [ref=f2e444] [cursor=pointer]
                    - generic [ref=f2e445] [cursor=pointer]
                    - generic [ref=f2e446] [cursor=pointer]
                    - generic [ref=f2e447] [cursor=pointer]
                    - generic [ref=f2e448] [cursor=pointer]
                    - generic [ref=f2e449] [cursor=pointer]
                    - generic [ref=f2e450] [cursor=pointer]
                    - generic [ref=f2e451] [cursor=pointer]
                    - generic [ref=f2e452] [cursor=pointer]
                    - generic [ref=f2e453] [cursor=pointer]
                    - generic [ref=f2e454] [cursor=pointer]
                    - generic [ref=f2e455] [cursor=pointer]
                    - generic [ref=f2e456] [cursor=pointer]
                    - generic [ref=f2e457] [cursor=pointer]
                    - generic [ref=f2e458] [cursor=pointer]
                    - generic [ref=f2e459] [cursor=pointer]
                    - generic [ref=f2e460] [cursor=pointer]
                    - generic [ref=f2e461] [cursor=pointer]
                    - generic [ref=f2e462] [cursor=pointer]
                    - generic [ref=f2e463] [cursor=pointer]
                    - generic [ref=f2e464] [cursor=pointer]
                    - generic [ref=f2e465] [cursor=pointer]
                    - generic [ref=f2e466] [cursor=pointer]
                    - generic [ref=f2e467] [cursor=pointer]
                    - generic [ref=f2e468] [cursor=pointer]
                    - generic [ref=f2e469] [cursor=pointer]
                    - generic [ref=f2e470] [cursor=pointer]
                    - generic [ref=f2e471] [cursor=pointer]
                    - generic [ref=f2e472] [cursor=pointer]
                    - generic [ref=f2e473] [cursor=pointer]
                    - generic [ref=f2e474] [cursor=pointer]
                    - generic [ref=f2e475] [cursor=pointer]
                    - generic [ref=f2e476] [cursor=pointer]
                    - generic [ref=f2e477] [cursor=pointer]
                    - generic [ref=f2e478] [cursor=pointer]
                    - generic [ref=f2e479] [cursor=pointer]
                    - generic [ref=f2e480] [cursor=pointer]
                    - generic [ref=f2e481] [cursor=pointer]
                  - generic [ref=f2e482]:
                    - generic [ref=f2e483] [cursor=pointer]
                    - generic [ref=f2e484] [cursor=pointer]
                    - generic [ref=f2e485] [cursor=pointer]
                    - generic [ref=f2e486] [cursor=pointer]
                    - generic [ref=f2e487] [cursor=pointer]
                    - generic [ref=f2e488] [cursor=pointer]
                    - generic [ref=f2e489] [cursor=pointer]
                    - generic [ref=f2e490] [cursor=pointer]
                    - generic [ref=f2e491] [cursor=pointer]
                    - generic [ref=f2e492] [cursor=pointer]
                    - generic [ref=f2e493] [cursor=pointer]
                    - generic [ref=f2e494] [cursor=pointer]
                    - generic [ref=f2e495] [cursor=pointer]
                    - generic [ref=f2e496] [cursor=pointer]
                    - generic [ref=f2e497] [cursor=pointer]
                    - generic [ref=f2e498] [cursor=pointer]
                    - generic [ref=f2e499] [cursor=pointer]
                    - generic [ref=f2e500] [cursor=pointer]
                    - generic [ref=f2e501] [cursor=pointer]
                    - generic [ref=f2e502] [cursor=pointer]
                    - generic [ref=f2e503] [cursor=pointer]
                    - generic [ref=f2e504] [cursor=pointer]
                    - generic [ref=f2e505] [cursor=pointer]
                    - generic [ref=f2e506] [cursor=pointer]
                    - generic [ref=f2e507] [cursor=pointer]
                    - generic [ref=f2e508] [cursor=pointer]
                    - generic [ref=f2e509] [cursor=pointer]
                    - generic [ref=f2e510] [cursor=pointer]
                    - generic [ref=f2e511] [cursor=pointer]
                    - generic [ref=f2e512] [cursor=pointer]
                    - generic [ref=f2e513] [cursor=pointer]
                    - generic [ref=f2e514] [cursor=pointer]
                    - generic [ref=f2e515] [cursor=pointer]
                    - generic [ref=f2e516] [cursor=pointer]
                    - generic [ref=f2e517] [cursor=pointer]
                    - generic [ref=f2e518] [cursor=pointer]
                    - generic [ref=f2e519] [cursor=pointer]
                    - generic [ref=f2e520] [cursor=pointer]
                    - generic [ref=f2e521] [cursor=pointer]
                    - generic [ref=f2e522] [cursor=pointer]
                    - generic [ref=f2e523] [cursor=pointer]
                    - generic [ref=f2e524] [cursor=pointer]
                    - generic [ref=f2e525] [cursor=pointer]
                    - generic [ref=f2e526] [cursor=pointer]
                    - generic [ref=f2e527] [cursor=pointer]
                    - generic [ref=f2e528] [cursor=pointer]
                    - generic [ref=f2e529] [cursor=pointer]
                    - generic [ref=f2e530] [cursor=pointer]
            - paragraph [ref=f2e531]: No scheduled broadcasts yet.
        - generic [ref=f2e532]:
          - generic [ref=f2e533]:
            - generic [ref=f2e534]:
              - heading "Destinations" [level=2] [ref=f2e535]
              - paragraph [ref=f2e536]: Save your streaming destinations and manage their protected keys.
            - button "Add destination" [ref=f2e537] [cursor=pointer]
          - paragraph [ref=f2e539]: No saved destinations yet.
```

# Test source

```ts
  214 | 	const world = presentationState(mcpWorld.input);
  215 | 	const deadline = Date.now() + 20000;
  216 | 	const pool = new Pool({ connectionString: browserDatabaseUrl(), max: 1 });
  217 | 	try {
  218 | 		await pool.query("UPDATE users SET plan='free' WHERE id=$1", [world.owner.fixture.creatorId]);
  219 | 		await pool.query("INSERT INTO entitlement_grants(user_id,entitlement,source,starts_at,ends_at) VALUES($1,'pro_access','reverse_trial',now()-interval '1 hour',$2)", [world.owner.fixture.creatorId, new Date(deadline)]);
  220 | 		await pool.query("UPDATE runner_broadcast_admissions SET benefits_at_start=benefits_at_start || $2::jsonb WHERE session_id=$1", [world.sessionId, JSON.stringify({ runnerPro: true, validUntil: new Date(deadline).toISOString() })]);
  221 | 		await pool.query("INSERT INTO runner_branding_profiles(owner_id,runner_id,watermark_corner,pro_show_attribution) VALUES($1,$2,'top_left',false)", [world.owner.fixture.creatorId, world.runnerId]);
  222 | 	} finally {
  223 | 		await pool.end();
  224 | 	}
  225 | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  226 | 	expect(response.status()).toBe(200);
  227 | 	const { url } = await response.json();
  228 | 	await page.goto(`http://127.0.0.1:3107${url}`);
  229 | 	await page.waitForFunction(() => typeof (window as Window & { startRunnerPlayback?: () => void }).startRunnerPlayback === "function");
  230 | 	await page.evaluate(() => (window as Window & { startRunnerPlayback?: () => void }).startRunnerPlayback?.());
  231 | 	const video = page.locator("video").first();
  232 | 	await expect.poll(() => video.evaluate((element) => (element as HTMLVideoElement).currentTime)).toBeGreaterThan(0.2);
  233 | 	await expect(page.locator("[data-runner-presentation-generation]")).toHaveAttribute("data-runner-layout-status", "clean");
  234 | 	await expect(page.locator("[data-runner-attribution]")).toHaveCount(0);
  235 | 	expect(Date.now(), "Fixture must still be paid before the observed transition").toBeLessThan(deadline);
  236 | 	const beforeTime = await video.evaluate((element, marker) => {
  237 | 		(element as HTMLVideoElement).dataset.expiryContinuity = marker;
  238 | 		return (element as HTMLVideoElement).currentTime;
  239 | 	}, world.generation);
  240 | 	mcpWorld.input = { ...mcpWorld.input, runnerPresentationExpiry: { deadline, beforeTime } };
  241 | });
  242 | 
  243 | Then("required branding returns while its original clip and execution keep running", async ({ page, mcpWorld }) => {
  244 | 	const world = presentationState(mcpWorld.input);
  245 | 	const { deadline, beforeTime } = mcpWorld.input!.runnerPresentationExpiry as { deadline: number; beforeTime: number };
  246 | 	await expect(page.getByLabel("Livestream powered by Clipify.us", { exact: true })).toBeVisible({ timeout: Math.max(0, deadline - Date.now()) + 5000 });
  247 | 	await expect(page.locator("[data-runner-presentation-generation]")).toHaveAttribute("data-runner-presentation-generation", world.generation);
  248 | 	const originalVideo = page.locator(`video[data-expiry-continuity="${world.generation}"]`);
  249 | 	await expect(originalVideo).toHaveCount(1);
  250 | 	await expect.poll(() => originalVideo.evaluate((element) => (element as HTMLVideoElement).currentTime)).toBeGreaterThan(beforeTime);
  251 | 	const pool = new Pool({ connectionString: browserDatabaseUrl(), max: 1 });
  252 | 	try {
  253 | 		const execution = (await pool.query("SELECT state,execution_generation FROM runner_broadcast_admissions WHERE session_id=$1", [world.sessionId])).rows;
  254 | 		expect(execution).toEqual([{ state: "active", execution_generation: world.generation }]);
  255 | 		const settings = (await pool.query("SELECT watermark_corner,pro_show_attribution,revision FROM runner_branding_profiles WHERE runner_id=$1", [world.runnerId])).rows;
  256 | 		expect(settings).toEqual([{ watermark_corner: "top_left", pro_show_attribution: false, revision: 1 }]);
  257 | 	} finally {
  258 | 		await pool.end();
  259 | 	}
  260 | });
  261 | 
  262 | When("its owner renews Pro before that deadline", async ({ mcpWorld }) => {
  263 | 	const world = presentationState(mcpWorld.input);
  264 | 	const { deadline } = mcpWorld.input!.runnerPresentationExpiry as { deadline: number };
  265 | 	expect(Date.now()).toBeLessThan(deadline);
  266 | 	const renewedDeadline = deadline + 60000;
  267 | 	const pool = new Pool({ connectionString: browserDatabaseUrl(), max: 1 });
  268 | 	try {
  269 | 		const renewed = await pool.query("UPDATE entitlement_grants SET ends_at=$2 WHERE user_id=$1 AND entitlement='pro_access' AND source='reverse_trial' RETURNING ends_at", [world.owner.fixture.creatorId, new Date(renewedDeadline)]);
  270 | 		expect(renewed.rowCount).toBe(1);
  271 | 	} finally {
  272 | 		await pool.end();
  273 | 	}
  274 | 	mcpWorld.input = { ...mcpWorld.input, runnerRenewedAppearanceDeadline: renewedDeadline };
  275 | });
  276 | 
  277 | Then("its original clip stays clean beyond the former deadline", async ({ page, mcpWorld }) => {
  278 | 	const world = presentationState(mcpWorld.input);
  279 | 	const { deadline, beforeTime } = mcpWorld.input!.runnerPresentationExpiry as { deadline: number; beforeTime: number };
  280 | 	await expect.poll(() => Date.now(), { timeout: Math.max(0, deadline - Date.now()) + 5000 }).toBeGreaterThan(deadline + 500);
  281 | 	expect(Date.now()).toBeLessThan(mcpWorld.input!.runnerRenewedAppearanceDeadline as number);
  282 | 	await expect(page.locator("[data-runner-attribution]")).toHaveCount(0);
  283 | 	await expect(page.locator("[data-runner-presentation-generation]")).toHaveAttribute("data-runner-presentation-generation", world.generation);
  284 | 	await expect(page.locator("[data-runner-presentation-generation]")).toHaveAttribute("data-runner-layout-status", "clean");
  285 | 	const video = page.locator(`video[data-expiry-continuity="${world.generation}"]`);
  286 | 	await expect(video).toHaveCount(1);
  287 | 	await expect.poll(() => video.evaluate((element) => (element as HTMLVideoElement).currentTime)).toBeGreaterThan(beforeTime);
  288 | });
  289 | 
  290 | Then("their standby background color matches draft preview and saved generated standby", async ({ page, mcpWorld }) => {
  291 | 	const color = page.getByLabel("Standby background color", { exact: true });
  292 | 	await expect(color).toBeVisible();
  293 | 	await color.fill("#16324f");
  294 | 	const standby = page.frameLocator('iframe[title="Runner appearance preview"]').locator("[data-runner-standby]");
  295 | 	await expect(standby).toHaveCSS("background-color", "rgb(22, 50, 79)");
  296 | 	await page.getByRole("button", { name: "Save appearance", exact: true }).click();
  297 | 	await expect(page.getByRole("status").filter({ hasText: "Appearance saved" })).toBeVisible();
  298 | 	await page.reload();
  299 | 	await expect(color).toHaveValue("#16324f");
  300 | 	await expect(standby).toHaveCSS("background-color", "rgb(22, 50, 79)");
  301 | 	const world = presentationState(mcpWorld.input);
  302 | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  303 | 	expect(response.status()).toBe(200);
  304 | 	const { url } = await response.json();
  305 | 	await page.goto(`http://127.0.0.1:3107${url}`);
  306 | 	await expect(page.locator("[data-runner-standby]")).toHaveCSS("background-color", "rgb(22, 50, 79)");
  307 | });
  308 | 
  309 | Then("their uploaded background image matches preview and saved generated standby", async ({ page, mcpWorld }) => {
  310 | 	const sharp = (await import("sharp")).default;
  311 | 	const bytes = await sharp({ create: { width: 16, height: 16, channels: 3, background: { r: 40, g: 120, b: 200 } } })
  312 | 		.png()
  313 | 		.toBuffer();
> 314 | 	await page.getByLabel("Standby background image", { exact: true }).setInputFiles({ name: "standby.png", mimeType: "image/png", buffer: bytes });
      |  ^ Error: locator.setInputFiles: Test timeout of 60000ms exceeded.
  315 | 	const preview = page.frameLocator('iframe[title="Runner appearance preview"]').getByRole("img", { name: "Standby background", exact: true });
  316 | 	await expect(preview).toBeVisible();
  317 | 	await expect(preview).toHaveJSProperty("naturalWidth", 16);
  318 | 	await expect(preview).toHaveJSProperty("naturalHeight", 16);
  319 | 	await page.getByRole("button", { name: "Save appearance", exact: true }).click();
  320 | 	await expect(page.getByRole("status").filter({ hasText: "Appearance saved" })).toBeVisible();
  321 | 	await page.reload();
  322 | 	await expect(preview).toBeVisible();
  323 | 	await expect(preview).toHaveJSProperty("naturalWidth", 16);
  324 | 	const world = presentationState(mcpWorld.input);
  325 | 	const response = await page.request.post("http://127.0.0.1:3107/api/runner/presentation", { headers: { Authorization: `Bearer ${world.token}` }, data: { sessionId: world.sessionId, executionGeneration: world.generation } });
  326 | 	expect(response.status()).toBe(200);
  327 | 	const { url } = await response.json();
  328 | 	await page.goto(`http://127.0.0.1:3107${url}`);
  329 | 	const image = page.getByRole("img", { name: "Standby background", exact: true });
  330 | 	await expect(image).toBeVisible();
  331 | 	await expect(image).toHaveJSProperty("naturalWidth", 16);
  332 | 	await expect(image).toHaveJSProperty("naturalHeight", 16);
  333 | });
  334 | 
```