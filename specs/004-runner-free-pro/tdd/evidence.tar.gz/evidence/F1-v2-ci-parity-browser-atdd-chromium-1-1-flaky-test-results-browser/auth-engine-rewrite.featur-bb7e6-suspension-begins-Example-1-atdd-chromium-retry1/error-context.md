# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: .features-gen/atdd/auth-engine-rewrite.feature.spec.js >> Creator identity and delegated team access >> Owner chooses when deletion suspension begins >> Example #1
- Location: .features-gen/atdd/auth-engine-rewrite.feature.spec.js:138:9

# Error details

```
Test timeout of 180000ms exceeded.
```

```
Error: locator.fill: Test timeout of 180000ms exceeded.
Call log:
  - waiting for getByRole('dialog').getByPlaceholder('e2e_4dbbc1ee1a09')

```

# Page snapshot

```yaml
- generic [ref=f1e1]:
  - button "Enable support chat" [ref=f1e2] [cursor=pointer]
  - button "Report a problem" [ref=f1e3] [cursor=pointer]
  - alert [ref=f1e8]
  - navigation [ref=f1e9]:
    - generic [ref=f1e10]:
      - link [ref=f1e11] [cursor=pointer]:
        - /url: /dashboard
        - paragraph [ref=f1e16]: Clipify
      - list [ref=f1e17]:
        - listitem [ref=f1e18]:
          - generic [ref=f1e19]:
            - generic [ref=f1e20]: Account
            - group [ref=f1e21] [cursor=pointer]:
              - generic [ref=f1e25]: E2E Creator Account
              - button "E2E Creator Account Account context Account"
            - combobox [ref=f1e30]
        - listitem [ref=f1e31]:
          - button "Toggle Theme" [ref=f1e32] [cursor=pointer]
        - listitem [ref=f1e33]:
          - button "Open profile menu" [ref=f1e34] [cursor=pointer]:
            - generic [ref=f1e35]:
              - generic [ref=f1e36]: E2
              - status "Online" [ref=f1e38]
  - main [ref=f1e40]:
    - generic [ref=f1e41]:
      - generic [ref=f1e43]:
        - heading "Settings" [level=1] [ref=f1e44]
        - paragraph [ref=f1e45]: Manage your settings
      - tablist "Settings sections" [ref=f1e50]:
        - tab "Settings" [selected] [ref=f1e51] [cursor=pointer]
        - tab "Creator Page" [ref=f1e53] [cursor=pointer]
        - tab "Billing" [ref=f1e54] [cursor=pointer]
        - tab "Team" [ref=f1e55] [cursor=pointer]
      - generic [ref=f1e56]:
        - generic [ref=f1e59]:
          - generic [ref=f1e61]:
            - generic [ref=f1e62]:
              - generic [ref=f1e63]: "User ID:"
              - code [ref=f1e64]: e2e-creator-4dbbc1ee-1a09-43ae-bcc3-6b9da215041d
            - button "Copy to clipboard" [ref=f1e65] [cursor=pointer]
          - button "About your user ID" [ref=f1e66] [cursor=pointer]
        - generic [ref=f1e67]:
          - generic [ref=f1e68]:
            - generic [ref=f1e69]: E2
            - generic [ref=f1e72]:
              - paragraph [ref=f1e73]: e2e_4dbbc1ee1a09
              - paragraph [ref=f1e74]: "Plan: Pro"
          - separator [ref=f1e75]
          - generic [ref=f1e76]:
            - generic [ref=f1e77]:
              - generic [ref=f1e78]:
                - generic [ref=f1e84]:
                  - paragraph [ref=f1e85]: Clip crawl status
                  - paragraph [ref=f1e86]: Your clip cache is checked in the background about every minute.
                - generic [ref=f1e87]: Syncing
              - generic [ref=f1e88]:
                - paragraph [ref=f1e89]: "Manual refresh: available now"
                - generic [ref=f1e90]:
                  - button "Refresh statistics" [ref=f1e91] [cursor=pointer]
                  - button "Force Refresh Cache" [ref=f1e92] [cursor=pointer]
              - paragraph [ref=f1e94]: Cached clips are stored clip records used by the player so playback works quickly without refetching everything from Twitch on each request.
              - generic [ref=f1e95]:
                - paragraph [ref=f1e96]: "Backfill progress (estimate): 0%"
                - paragraph [ref=f1e97]: "Cached clips: 0"
                - paragraph [ref=f1e98]: "Unavailable clips: 0"
                - paragraph [ref=f1e99]: "Oldest cached clip: Never"
                - paragraph [ref=f1e100]: "Last fresh sync: Never"
                - paragraph [ref=f1e101]: "Last backfill sync: Never"
                - paragraph [ref=f1e102]: "Last manual refresh: Never"
            - separator [ref=f1e103]
            - generic [ref=f1e104]:
              - generic [ref=f1e105]:
                - generic [ref=f1e106]: Command Prefix*
                - textbox "Command Prefix*" [ref=f1e107]: "!"
                - generic [ref=f1e108]: Maximum of 3 characters. This prefix will be used for all bot commands.
              - generic [ref=f1e110]:
                - generic [ref=f1e111]:
                  - generic [ref=f1e112]:
                    - paragraph [ref=f1e113]: Email Preferences
                    - paragraph [ref=f1e114]: Product updates and occasional special offers.
                  - switch "Receive emails" [checked] [ref=f1e118]
                - paragraph [ref=f1e121]: Opt out anytime here or by using the unsubscribe link in any email.
                - paragraph [ref=f1e122]: Consent recorded on 10/18/2026, 5:31:17 AM.
              - generic [ref=f1e124]:
                - generic [ref=f1e125]:
                  - generic [ref=f1e126]:
                    - paragraph [ref=f1e127]: Search engines and Clipify Discovery
                    - paragraph [ref=f1e128]: Controls whether your Creator Page appears in search, the sitemap, and Clipify discovery. The direct URL continues to work when disabled.
                  - switch "Appear in search engines and Clipify Discovery" [checked] [ref=f1e132]
                - paragraph [ref=f1e135]:
                  - text: Creator Page availability and profile content are configured in the
                  - link "Creator Page tab" [ref=f1e136] [cursor=pointer]
                  - text: .
              - generic [ref=f1e137]:
                - generic [ref=f1e139]:
                  - heading "Sign-in & security" [level=3] [ref=f1e140]
                  - paragraph [ref=f1e141]: Manage the email and passkeys used to access your account.
                - generic [ref=f1e142]:
                  - generic [ref=f1e143]:
                    - generic [ref=f1e144]:
                      - paragraph [ref=f1e145]: Your email
                      - generic [ref=f1e146]:
                        - generic [ref=f1e147]: e2e-4dbbc1ee-1a09-43ae-bcc3-6b9da215041d@example.invalid
                        - generic [ref=f1e148]: Verified
                    - button "Change email" [ref=f1e150] [cursor=pointer]
                  - generic [ref=f1e151]:
                    - generic [ref=f1e152]:
                      - paragraph [ref=f1e153]: Passkeys
                      - paragraph [ref=f1e154]: No passkeys registered
                    - button "Manage passkeys" [ref=f1e155] [cursor=pointer]
              - generic [ref=f1e156]:
                - generic [ref=f1e157]:
                  - heading "Connected AI apps" [level=2] [ref=f1e167]
                  - paragraph [ref=f1e168]: Manage which apps can access your creators. Disconnecting an app stops its access immediately.
                  - link "Connect your AI tools" [ref=f1e169] [cursor=pointer]:
                    - /url: https://help.clipify.us/hc/clipify/articles/connect-clipify-to-ai-apps
                - generic [ref=f1e174]:
                  - generic [ref=f1e176]:
                    - heading "No connected apps." [level=3] [ref=f1e181]
                    - paragraph [ref=f1e182]: Apps you approve through Clipify will appear here.
                  - heading [level=3] [ref=f1e185]:
                    - button "Ideas to try with your AI app" [ref=f1e186] [cursor=pointer]
              - region [ref=f1e189]:
                - generic [ref=f1e190]:
                  - heading "AI app activity" [level=2] [ref=f1e195]
                  - paragraph [ref=f1e196]: Review what connected apps did and which requests were blocked. Activity follows your current creator access.
                - generic [ref=f1e197]:
                  - generic [ref=f1e198]:
                    - generic [ref=f1e199]:
                      - generic [ref=f1e200]: Creator
                      - button "e2e_4dbbc1ee1a09 Creator Creator" [ref=f1e201] [cursor=pointer]:
                        - generic [ref=f1e202]: e2e_4dbbc1ee1a09
                      - combobox [ref=f1e207]
                    - button "Refresh activity" [ref=f1e208] [cursor=pointer]: Refresh
                  - generic [ref=f1e210]:
                    - heading "No activity yet" [level=3] [ref=f1e215]
                    - paragraph [ref=f1e216]: Activity will appear when an approved app uses Clipify tools.
              - generic [ref=f1e219]:
                - generic [ref=f1e220]:
                  - paragraph [ref=f1e221]: Team access
                  - paragraph [ref=f1e222]: Invite team members and assign preset or custom permissions.
                - button "Manage team" [ref=f1e223] [cursor=pointer]
              - button "Save Settings" [disabled]
            - separator [ref=f1e224]
            - generic [ref=f1e225]:
              - button "Export Account Data" [ref=f1e226] [cursor=pointer]: Request Account Data
              - button "Schedule Account Deletion" [active] [ref=f1e227] [cursor=pointer]
              - generic [ref=f1e228]: Account deletion keeps your resources recoverable for 30 days before permanent erasure.
```

# Test source

```ts
  387 | 	authWorld.values.set("deletionRequest", domainRequest);
  388 | });
  389 | 
  390 | When(/^(.+) has elapsed$/, async ({ page, request, authWorld }, recoveryTime: string) => {
  391 | 	const deletionRequest = authWorld.values.get("deletionRequest") as { status: "suspended"; purgeEligibleAt: Date };
  392 | 	const now = recoveryTime === "less than 30 days" ? new Date(deletionRequest.purgeEligibleAt.getTime() - 1) : deletionRequest.purgeEligibleAt;
  393 | 	authWorld.values.set("deletionBoundary", evaluateDeletionBoundary(deletionRequest, now));
  394 | 	const fixture = authWorld.values.get("realLifecycleFixture") as AuthFixture;
  395 | 	if (recoveryTime === "at least 30 days") {
  396 | 		const adjusted = await request.patch("/api/test/auth-fixture", { headers: { Authorization: "Bearer clipify-playwright-auth-fixture" }, data: { deletionRequestId: fixture.fixture.deletionRequestId, deletionBoundary: "expired" } });
  397 | 		expect(adjusted.ok(), await adjusted.text()).toBe(true);
  398 | 	}
  399 | 	await page.goto("/dashboard/settings/account/recovery");
  400 | 	await expect(page.getByRole("heading", { name: recoveryTime === "at least 30 days" ? "Recovery period ended" : "Account suspended pending deletion" })).toBeVisible({ timeout: 30_000 });
  401 | 	await prepareInteractivePage(page);
  402 | 	authWorld.values.set("realDeletionBoundary", {
  403 | 		recoverable: await page.getByRole("button", { name: "Recover my account" }).isVisible(),
  404 | 		ended: await page.getByText("Recovery period ended", { exact: false }).isVisible(),
  405 | 	});
  406 | });
  407 | 
  408 | Then(/^the account (.+)$/, async ({ authWorld }, outcome: string) => {
  409 | 	expect(authWorld.values.get("deletionBoundary")).toBe(outcome.includes("remains recoverable") ? "recoverable" : "purge_eligible");
  410 | 	const real = authWorld.values.get("realDeletionBoundary") as { recoverable: boolean; ended: boolean };
  411 | 	expect(real.recoverable).toBe(outcome.includes("remains recoverable"));
  412 | 	expect(real.ended).toBe(outcome.includes("eligible for permanent erasure"));
  413 | });
  414 | 
  415 | Given("a suspended creator account with a recovery entry point", async ({ request, context, authWorld }) => {
  416 | 	const fixture = await createAuthenticatedFixture(request, context, { deletionState: "suspended", withProviderCredentials: true });
  417 | 	authWorld.values.set("realLifecycleFixture", fixture);
  418 | 	const repository = new LifecycleScenarioRepository();
  419 | 	const service = new AccountLifecycleService(repository, { now: () => LIFECYCLE_NOW });
  420 | 	const domainRequest = await service.requestDeletion(lifecycleOwner(), { choice: "immediate" });
  421 | 	authWorld.values.set("lifecycleRepository", repository);
  422 | 	authWorld.values.set("deletionRequest", domainRequest);
  423 | });
  424 | 
  425 | When("the owner signs in confirms identity and cancels deletion before 30 days", async ({ page, authWorld }) => {
  426 | 	const repository = authWorld.values.get("lifecycleRepository") as LifecycleScenarioRepository;
  427 | 	const request = authWorld.values.get("deletionRequest") as { id: string };
  428 | 	const recoveryAt = new Date(LIFECYCLE_NOW.getTime() + 10 * 24 * 60 * 60 * 1000);
  429 | 	const effects: string[] = [];
  430 | 	const recovered = await recoverDeletion(repository, lifecycleOwner(recoveryAt), {
  431 | 		requestId: request.id,
  432 | 		now: recoveryAt,
  433 | 		resumeRuntime: async () => void effects.push("runtime"),
  434 | 		restartBilling: async () => void effects.push("billing"),
  435 | 		reclaimAgencyAllocation: async () => void effects.push("allocation"),
  436 | 	});
  437 | 	let linkOnlyError: unknown;
  438 | 	try {
  439 | 		await recoverDeletion(repository, lifecycleOwner(recoveryAt), { requestId: request.id, now: recoveryAt, recoveryEntryOnly: true });
  440 | 	} catch (error) {
  441 | 		linkOnlyError = error;
  442 | 	}
  443 | 	authWorld.values.set("recoveryResult", { recovered, effects, linkOnlyError });
  444 | 	await page.goto("/dashboard/settings/account/recovery");
  445 | 	await expect(page.getByRole("heading", { name: "Account suspended pending deletion" })).toBeVisible({ timeout: 30_000 });
  446 | 	await prepareInteractivePage(page);
  447 | 	await page.getByRole("button", { name: "Recover my account" }).click();
  448 | 	await expect(page).toHaveURL(/\/dashboard$/, { timeout: DATABASE_ACTION_TIMEOUT_MS });
  449 | 	authWorld.values.set("realRecoveryCompleted", true);
  450 | });
  451 | 
  452 | Then("account dashboard overlay and integration access are restored", async ({ authWorld }) => {
  453 | 	const result = authWorld.values.get("recoveryResult") as { recovered: { status: string }; effects: string[] };
  454 | 	expect(result.recovered.status).toBe("recovered");
  455 | 	expect(result.effects).toEqual(["runtime"]);
  456 | 	expect(authWorld.values.get("realRecoveryCompleted")).toBe(true);
  457 | });
  458 | 
  459 | Then("the recovery entry point alone cannot authenticate the owner", async ({ authWorld }) => {
  460 | 	expect((authWorld.values.get("recoveryResult") as { linkOnlyError: Error }).linkOnlyError).toEqual(expect.objectContaining({ message: "AUTHENTICATION_REQUIRED" }));
  461 | });
  462 | 
  463 | Then("billing and agency allocations are not restarted", async ({ authWorld }) => {
  464 | 	expect((authWorld.values.get("recoveryResult") as { effects: string[] }).effects).not.toEqual(expect.arrayContaining(["billing", "allocation"]));
  465 | });
  466 | 
  467 | Given("a recently authenticated owner with paid access through a future date", async ({ request, context, authWorld }) => {
  468 | 	const fixture = await createAuthenticatedFixture(request, context, { deletionState: "none", billingState: "active" });
  469 | 	authWorld.values.set("realLifecycleFixture", fixture);
  470 | 	authWorld.values.set("lifecycleRepository", new LifecycleScenarioRepository());
  471 | });
  472 | 
  473 | When(/^the owner chooses (.+)$/, async ({ page, authWorld }, deletionChoice: string) => {
  474 | 	const repository = authWorld.values.get("lifecycleRepository") as LifecycleScenarioRepository;
  475 | 	const effects: string[] = [];
  476 | 	const request = await new AccountLifecycleService(repository, { now: () => LIFECYCLE_NOW, revokeSessions: async () => void effects.push("sessions"), pauseRuntime: async () => void effects.push("runtime") }).requestDeletion(lifecycleOwner(), {
  477 | 		choice: deletionChoice === "delete now" ? "immediate" : "paid_through",
  478 | 	});
  479 | 	const fixture = authWorld.values.get("realLifecycleFixture") as AuthFixture;
  480 | 	const username = fixture.fixture.username;
  481 | 	await page.goto("/dashboard/settings");
  482 | 	await expect(page.getByRole("heading", { name: "Settings" })).toBeVisible({ timeout: 30_000 });
  483 | 	await prepareInteractivePage(page);
  484 | 	await page.getByRole("button", { name: "Schedule Account Deletion" }).click();
  485 | 	const dialog = page.getByRole("dialog");
  486 | 	if (deletionChoice === "delete now") await dialog.getByRole("button", { name: "Suspend now" }).click();
> 487 | 	await dialog.getByPlaceholder(username).fill(username);
      |                                          ^ Error: locator.fill: Test timeout of 180000ms exceeded.
  488 | 	await dialog.getByRole("button", { name: deletionChoice === "delete now" ? "Delete after confirmation" : "Schedule deletion" }).click();
  489 | 	if (deletionChoice === "delete now") await expect(page).toHaveURL(/\/login\?returnUrl=/, { timeout: DATABASE_ACTION_TIMEOUT_MS });
  490 | 	else await expect(page.getByText("Deletion scheduled", { exact: true })).toBeVisible({ timeout: DATABASE_ACTION_TIMEOUT_MS });
  491 | 	authWorld.values.set("realDeletionChoiceCompleted", true);
  492 | 	authWorld.values.set("deletionChoiceResult", { request, effects });
  493 | });
  494 | 
  495 | Then(/^suspension starts (.+)$/, async ({ authWorld }, expected: string) => {
  496 | 	const result = authWorld.values.get("deletionChoiceResult") as { request: { suspensionAt: Date }; effects: string[] };
  497 | 	expect(result.request.suspensionAt).toEqual(expected.includes("paid-through") ? LIFECYCLE_PERIOD_END : LIFECYCLE_NOW);
  498 | 	if (expected.includes("data retained")) expect((authWorld.values.get("lifecycleRepository") as LifecycleScenarioRepository).state.resources).toHaveLength(1);
  499 | 	expect(authWorld.values.get("realDeletionChoiceCompleted")).toBe(true);
  500 | });
  501 | 
  502 | Then("Stripe remains responsible for billing lifecycle notices", async ({ authWorld }) => {
  503 | 	expect(authWorld.values.has("clipifyBillingNotice")).toBe(false);
  504 | });
  505 | 
```