from pathlib import Path
import hashlib,json,subprocess
root=Path(__file__).resolve().parents[4];source=root/'src/server/runner/admission.ts';evidence=root/'specs/004-runner-free-pro/tdd/evidence';original=source.read_bytes();needle=b'if (capabilities.maxActiveBroadcasts !== null && occupied.length >= capabilities.maxActiveBroadcasts)';assert original.count(needle)==1
owners=['test/server/runner/admission-acceptance.test.ts'];report={'scope':'owner-wide admission limit fault; excluded from passing qualification','source':str(source.relative_to(root)),'beforeSha256':hashlib.sha256(original).hexdigest(),'owners':owners,'ok':False}
input_record=json.loads((evidence/'F1-review-final-execution-inputs.json').read_text())
input_hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in input_record['sha256']}
assert input_hashes==input_record['sha256'], 'Strength input manifest is stale'
report['executionInputFingerprint']=input_record['sourceFingerprint']

def execute(phase):
 output=Path('/tmp')/('clipify-review-owner-'+phase+'.json');log=evidence/('F1-review-strength-owner-'+phase+'.log')
 with log.open('wb') as handle: result=subprocess.run(['bun','run','test','--runInBand','--runTestsByPath',*owners,'--coverage=false','--json','--outputFile='+str(output)],cwd=root,stdout=handle,stderr=subprocess.STDOUT,timeout=180)
 r=json.loads(output.read_text());return {'exitCode':result.returncode,'passed':r['numPassedTests'],'failed':r['numFailedTests'],'runtimeErrors':r.get('numRuntimeErrorTestSuites',0),'failedCases':[a['fullName'] for s in r['testResults'] for a in s.get('assertionResults',[]) if a['status']=='failed'],'log':str(log.relative_to(root))}
try:
 try:
  mutant=original.replace(needle,b'if (false)');source.write_bytes(mutant);report['mutantSha256']=hashlib.sha256(mutant).hexdigest();report['fault']=execute('fault')
 finally:source.write_bytes(original)
 report['restored']=execute('restored');report['ok']=report['fault']['exitCode']!=0 and report['fault']['failed']>0 and report['fault']['runtimeErrors']==0 and report['restored']['exitCode']==0
finally:
 source.write_bytes(original);report['allSourcesRestored']=source.read_bytes()==original;report['restoredSha256']=hashlib.sha256(source.read_bytes()).hexdigest();(evidence/'F1-review-owner-strength-results.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==v for p,v in input_hashes.items()), 'Strength inputs not restored'
print(json.dumps(report),flush=True)
if not report['ok']:raise SystemExit(1)
