from pathlib import Path
import re,json,collections
root=Path(__file__).resolve().parents[4];feature=root/'specs/004-runner-free-pro';s=(feature/'test-traceability.md').read_text();registry=s.split('## Evidence Artifact Registry',1)[1].split('## Source Coverage Map',1)[0]
rows=[l.split('|')[1:-1]for l in registry.splitlines()if re.match(r'^\|\s*(?:BDD|TDD|ATDD)-',l)];ids=[r[0].strip()for r in rows];states=collections.Counter(r[5].strip()for r in rows);tasks=re.findall(r'^- \[([ xX])\] (T\d+)\b',(feature/'tasks.md').read_text(),re.M);errors=[]
if len(ids)!=376 or len(set(ids))!=376:errors.append('Primary artifact count/identity changed')
if len(tasks)!=1046 or len({t for _,t in tasks})!=1046:errors.append('Task count/identity changed')
paths=[]
for row in rows:
 for p in re.findall(r'(?:test|packages/runner|src|scripts)/[A-Za-z0-9_./\[\]{}*-]+\.(?:tsx?|mjs|cjs|feature)',row[3]):
  paths.append(p)
  if not(root/p).exists() and not any(root.glob(p)):errors.append('Missing physical owner '+p)
source=s.split('## Source Coverage Map',1)[1].split('## Scenario Coverage Matrix',1)[0];mapped=set(re.findall(r'(?:BDD|ATDD|TDD)-US\d-[A-Z0-9]+',source));missing=set(ids)-mapped
if missing:errors.append('Unmapped artifacts '+','.join(sorted(missing)))
report={'ok':not errors,'errors':sorted(set(errors)),'primaryArtifacts':len(ids),'uniquePrimary':len(set(ids)),'primaryStates':dict(states),'taskCount':len(tasks),'uniqueTasks':len({t for _,t in tasks}),'tasksComplete':sum(x.lower()=='x'for x,_ in tasks),'mappedPrimaryArtifacts':len(set(ids)&mapped),'physicalOwnerReferences':len(paths),'scope':'Current relationship and physical-path integrity only. Historical Green artifact records do not replace current-source CI qualification.'};print(json.dumps(report,indent=2));(feature/'tdd/evidence/F1-review-final-mapping-audit.json').write_text(json.dumps(report,indent=2)+'\n')
if errors:raise SystemExit(1)
