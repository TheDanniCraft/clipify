from pathlib import Path
import hashlib,json,subprocess,sys
root=Path(__file__).resolve().parents[4]; native=root/'packages/runner'; evidence=root/'specs/004-runner-free-pro/tdd/evidence'
protocol=native/'src/protocol.ts'; engine=native/'src/engine.ts'
protocol_owners=['test/app/api/runner/heartbeat.test.ts']
engine_owners=['src/__tests__/capture-startup.test.ts','src/__tests__/engine.test.ts','src/__tests__/presentation-bootstrap.test.ts','src/__tests__/controller-drain.test.ts','src/__tests__/drain.test.ts']
window='return Number.isSafeInteger(now) && Number.isSafeInteger(claims.issuedAt) && Number.isSafeInteger(claims.expiresAt) && claims.issuedAt <= now && claims.expiresAt > now && claims.expiresAt > claims.issuedAt;'
identity='return (["ownerId", "runnerId", "sessionId", "generation", "targetHash", "configurationRevision", "sourceRevision"] as const).every((field) => claims[field] === expected[field]);'
cases=[('signature',protocol,'if (!verify(null, Buffer.from(payload), trustedKeys[keyId], Buffer.from(signature, "base64url"))) return null;','if (false) return null;',protocol_owners),('expiry',protocol,window,window.replace('claims.expiresAt > now','claims.expiresAt >= now'),protocol_owners),('identity',protocol,identity,'return true;',protocol_owners),('capture-fence',engine,'return this.mayOpenOutput() && !this.isForwardingObs && this.page === capturePage;','return true;',engine_owners),('clip-flush',engine,'finished = true;','finished = false;',engine_owners)]
originals={p:p.read_bytes() for p in [protocol,engine]}; report={'scope':'deliberate invariant faults after review refactors; excluded from passing qualification','cycles':[],'ok':False}
input_record=json.loads((evidence/'F1-review-final-execution-inputs.json').read_text())
input_hashes={p:hashlib.sha256((root/p).read_bytes()).hexdigest() for p in input_record['sha256']}
assert input_hashes==input_record['sha256'], 'Strength input manifest is stale'
report['executionInputFingerprint']=input_record['sourceFingerprint']

def digest(b):return hashlib.sha256(b).hexdigest()
def execute(name,phase,owners):
 output=Path('/tmp')/f'clipify-review-strength-{name}-{phase}.json'; log=evidence/f'F1-review-strength-{name}-{phase}.log'
 with log.open('wb') as handle:
  result=subprocess.run(['bun','run','test','--runInBand','--runTestsByPath',*owners,'--coverage=false','--json','--outputFile='+str(output)],cwd=(native if owners[0].startswith('src/') else root),stdout=handle,stderr=subprocess.STDOUT,timeout=180)
 results=json.loads(output.read_text());failed=[a['fullName'] for s in results.get('testResults',[]) for a in s.get('assertionResults',[]) if a['status']=='failed']
 return {'exitCode':result.returncode,'passed':results['numPassedTests'],'failed':results['numFailedTests'],'runtimeErrors':results.get('numRuntimeErrorTestSuites',0),'failedCases':failed,'log':str(log.relative_to(root))}
try:
 for name,path,before,after,owners in cases:
  original=originals[path];needle=before.encode();assert original.count(needle)==1,(name,'ambiguous target');mutant=original.replace(needle,after.encode()); cycle={'name':name,'source':str(path.relative_to(root)),'beforeSha256':digest(original),'mutantSha256':digest(mutant),'owners':owners};report['cycles'].append(cycle)
  try:
   path.write_bytes(mutant);cycle['fault']=execute(name,'fault',owners)
  finally:
   path.write_bytes(original);cycle['restoredSha256']=digest(path.read_bytes());assert path.read_bytes()==original
  cycle['restored']=execute(name,'restored',owners)
  cycle['killed']=cycle['fault']['exitCode']!=0 and cycle['fault']['failed']>0 and cycle['fault']['runtimeErrors']==0 and cycle['restored']['exitCode']==0 and cycle['restored']['failed']==0
  print(json.dumps({'name':name,'killed':cycle['killed'],'failedCases':cycle['fault']['failedCases']}),flush=True)
  if not cycle['killed']: raise RuntimeError('Invariant fault survived or failed for setup reasons: '+name)
 report['ok']=True
finally:
 for p,b in originals.items():p.write_bytes(b)
 report['allSourcesRestored']=all(p.read_bytes()==b for p,b in originals.items())
 (evidence/'F1-review-strength-results.json').write_text(json.dumps(report,indent=2)+'\n')
assert all(hashlib.sha256((root/p).read_bytes()).hexdigest()==v for p,v in input_hashes.items()), 'Strength inputs not restored'
if not report['ok']:sys.exit(1)
